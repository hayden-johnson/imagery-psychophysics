﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2023.1.3),
    on Wed Sep 25 00:02:57 2024
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import plugins
plugins.activatePlugins()
prefs.hardware['audioLib'] = 'ptb'
prefs.hardware['audioLatencyMode'] = '3'
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout
from psychopy.tools import environmenttools
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)
# Store info about the experiment session
psychopyVersion = '2023.1.3'
expName = 'imagery'  # from the Builder filename that created this script
expInfo = {
    'participant': f"{randint(0, 999999):06.0f}",
    'session': '001',
}
# --- Show participant info dialog --
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='/Users/hayden/Desktop/code/research/naselaris-lab/MindSweeper-2AFC/MindSweeper2AFC_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# --- Setup the Window ---
win = visual.Window(
    size=[1512, 982], fullscr=True, screen=0, 
    winType='pyglet', allowStencil=False,
    monitor='testMonitor', color=[0.5000, 0.5000, 0.5000], colorSpace='rgb',
    backgroundImage='', backgroundFit='none',
    blendMode='avg', useFBO=True, 
    units='pix')
win.mouseVisible = False
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess
# --- Setup input devices ---
ioConfig = {}
ioSession = ioServer = eyetracker = None

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard(backend='ptb')

# --- Initialize components for Routine "welcome" ---
welcomeText = visual.TextStim(win=win, name='welcomeText',
    text='Welcome! \n\n[loading experiment]',
    font='Open Sans',
    pos=(0, 0), height=50.0, wrapWidth=800.0, ori=0.0, 
    color=[-1.0000, -1.0000, -1.0000], colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# --- Initialize components for Routine "welcomeKey" ---
welcomeText2 = visual.TextStim(win=win, name='welcomeText2',
    text='Welcome! \n\n[space to continue]',
    font='Open Sans',
    pos=(0, 0), height=50.0, wrapWidth=650.0, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
key_resp_2 = keyboard.Keyboard()

# --- Initialize components for Routine "instructions" ---
intructionsText = visual.TextStim(win=win, name='intructionsText',
    text="Instructions (1/2):\n\n(1) A black line or curve will appear on the screen. Memorize it! It will disappear after 3 seconds.\n\n(2) A pink line will appear on the screen. Imagine that the black line/curve that you memorized was displayed on top of the pink line that you see. \n\n(3) How many times would they intersect? If it's more than the number on the screen, press the right arrow key. If it's less, press the left arrow key.\n\nLet’s give it a try!\n\n[space to continue]",
    font='Open Sans',
    pos=(0, 0), height=35.0, wrapWidth=650.0, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
continue_2 = keyboard.Keyboard()

# --- Initialize components for Routine "hands" ---
hand_placement = visual.TextStim(win=win, name='hand_placement',
    text='Instructions (2/2):\n\n(1) First, rest your fingers on the keyboard so that you can easily press the left and right arrow keys without having to move your hands. \n\n(2) Got it? Press the spacebar when you’re ready…\n\n[space to continue]',
    font='Open Sans',
    pos=(0, 0), height=35.0, wrapWidth=650.0, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
procede = keyboard.Keyboard()

# --- Initialize components for Routine "three" ---
three_ = visual.TextStim(win=win, name='three_',
    text='3',
    font='Open Sans',
    pos=(0, 0), height=50.0, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# --- Initialize components for Routine "two" ---
two_ = visual.TextStim(win=win, name='two_',
    text='2',
    font='Open Sans',
    pos=(0, 0), height=50.0, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# --- Initialize components for Routine "one" ---
one_ = visual.TextStim(win=win, name='one_',
    text='1',
    font='Open Sans',
    pos=(0, 0), height=50.0, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# --- Initialize components for Routine "zero" ---
zero_ = visual.TextStim(win=win, name='zero_',
    text=None,
    font='Open Sans',
    pos=(0, 0), height=50.0, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# --- Initialize components for Routine "warningBluePractice" ---
warningBluePract = visual.ImageStim(
    win=win,
    name='warningBluePract', 
    image='resources/blank.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(750, 750),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
practicePreTargetTxt = visual.TextStim(win=win, name='practicePreTargetTxt',
    text='memorize',
    font='Open Sans',
    pos=(0, 50), height=25.0, wrapWidth=None, ori=0.0, 
    color=[0.4824, 0.7176, 0.8588], colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);

# --- Initialize components for Routine "practiceTarget" ---
practiceTargetImg = visual.ImageStim(
    win=win,
    name='practiceTargetImg', 
    image='default.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(750, 750),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
practiceTargetText = visual.TextStim(win=win, name='practiceTargetText',
    text='',
    font='Open Sans',
    pos=(0, 300), height=30.0, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);

# --- Initialize components for Routine "pause" ---
blank_img2 = visual.ImageStim(
    win=win,
    name='blank_img2', 
    image='resources/blank.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(750, 750),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)

# --- Initialize components for Routine "isi" ---
blank_img = visual.ImageStim(
    win=win,
    name='blank_img', 
    image='resources/blank_red.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(750, 750),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)

# --- Initialize components for Routine "practiceProbe" ---
practiceResponse = keyboard.Keyboard()
practiceProbeImg = visual.ImageStim(
    win=win,
    name='practiceProbeImg', 
    image='default.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(750, 750),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-1.0)
practiceProbeText = visual.TextStim(win=win, name='practiceProbeText',
    text='',
    font='Open Sans',
    pos=(0, 50), height=25.0, wrapWidth=650.0, ori=0.0, 
    color=[0.4824, 0.7176, 0.8588], colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-3.0);

# --- Initialize components for Routine "practiceFeedbackCorrect" ---
showIsecsCorrect = visual.ImageStim(
    win=win,
    name='showIsecsCorrect', 
    image='default.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(750, 750),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
text_2 = visual.TextStim(win=win, name='text_2',
    text='Correct! ',
    font='Open Sans',
    pos=(0, 300), height=30.0, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);

# --- Initialize components for Routine "practiceFeedbackIncorrect" ---
showIsecsIncorrect = visual.ImageStim(
    win=win,
    name='showIsecsIncorrect', 
    image='default.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(750, 750),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
incorrectText = visual.TextStim(win=win, name='incorrectText',
    text='Incorrect',
    font='Open Sans',
    pos=(0, 300), height=30.0, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);

# --- Initialize components for Routine "begin" ---
text = visual.TextStim(win=win, name='text',
    text='Get ready!\n\nFrom now on, no feedback.\n\n[space to begin experiment]',
    font='Open Sans',
    pos=(0, 0), height=50.0, wrapWidth=800.0, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
begin_exp = keyboard.Keyboard()

# --- Initialize components for Routine "warningBlue" ---
blank_500_red = visual.ImageStim(
    win=win,
    name='blank_500_red', 
    image='resources/blank.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(750, 750),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
memory_reminder = visual.TextStim(win=win, name='memory_reminder',
    text='memorize',
    font='Open Sans',
    pos=(0, 50), height=25.0, wrapWidth=None, ori=0.0, 
    color=[0.4824, 0.7176, 0.8588], colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);

# --- Initialize components for Routine "target" ---
target_img = visual.ImageStim(
    win=win,
    name='target_img', 
    image='default.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(750, 750),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)

# --- Initialize components for Routine "pause" ---
blank_img2 = visual.ImageStim(
    win=win,
    name='blank_img2', 
    image='resources/blank.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(750, 750),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)

# --- Initialize components for Routine "isi" ---
blank_img = visual.ImageStim(
    win=win,
    name='blank_img', 
    image='resources/blank_red.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(750, 750),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)

# --- Initialize components for Routine "probe" ---
probeCurve = visual.ImageStim(
    win=win,
    name='probeCurve', 
    image='default.png', mask=None, anchor='center',
    ori=0.0, pos=(0,0), size=(750, 750),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
key_resp = keyboard.Keyboard()
comp = visual.TextStim(win=win, name='comp',
    text='',
    font='Open Sans',
    pos=(0, 50), height=25.0, wrapWidth=None, ori=0.0, 
    color=[0.4824, 0.7176, 0.8588], colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);

# --- Initialize components for Routine "takeBreak" ---
rest = visual.TextStim(win=win, name='rest',
    text='',
    font='Open Sans',
    pos=(0, 0), height=50.0, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# --- Initialize components for Routine "getReady" ---
ready = visual.TextStim(win=win, name='ready',
    text='Get ready ',
    font='Open Sans',
    pos=(0, 0), height=50.0, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# --- Initialize components for Routine "exit" ---
goodbyeText = visual.TextStim(win=win, name='goodbyeText',
    text="You're done! Please wait to be redirected...\n",
    font='Open Sans',
    pos=(0, 0), height=30.0, wrapWidth=650.0, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.Clock()  # to track time remaining of each (possibly non-slip) routine 

# --- Prepare to start Routine "welcome" ---
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
welcomeComponents = [welcomeText]
for thisComponent in welcomeComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "welcome" ---
routineForceEnded = not continueRoutine
while continueRoutine and routineTimer.getTime() < 3.0:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *welcomeText* updates
    
    # if welcomeText is starting this frame...
    if welcomeText.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        welcomeText.frameNStart = frameN  # exact frame index
        welcomeText.tStart = t  # local t and not account for scr refresh
        welcomeText.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(welcomeText, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'welcomeText.started')
        # update status
        welcomeText.status = STARTED
        welcomeText.setAutoDraw(True)
    
    # if welcomeText is active this frame...
    if welcomeText.status == STARTED:
        # update params
        pass
    
    # if welcomeText is stopping this frame...
    if welcomeText.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > welcomeText.tStartRefresh + 3-frameTolerance:
            # keep track of stop time/frame for later
            welcomeText.tStop = t  # not accounting for scr refresh
            welcomeText.frameNStop = frameN  # exact frame index
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'welcomeText.stopped')
            # update status
            welcomeText.status = FINISHED
            welcomeText.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
        if eyetracker:
            eyetracker.setConnectionState(False)
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in welcomeComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "welcome" ---
for thisComponent in welcomeComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
if routineForceEnded:
    routineTimer.reset()
else:
    routineTimer.addTime(-3.000000)

# --- Prepare to start Routine "welcomeKey" ---
continueRoutine = True
# update component parameters for each repeat
key_resp_2.keys = []
key_resp_2.rt = []
_key_resp_2_allKeys = []
# keep track of which components have finished
welcomeKeyComponents = [welcomeText2, key_resp_2]
for thisComponent in welcomeKeyComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "welcomeKey" ---
routineForceEnded = not continueRoutine
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *welcomeText2* updates
    
    # if welcomeText2 is starting this frame...
    if welcomeText2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        welcomeText2.frameNStart = frameN  # exact frame index
        welcomeText2.tStart = t  # local t and not account for scr refresh
        welcomeText2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(welcomeText2, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'welcomeText2.started')
        # update status
        welcomeText2.status = STARTED
        welcomeText2.setAutoDraw(True)
    
    # if welcomeText2 is active this frame...
    if welcomeText2.status == STARTED:
        # update params
        pass
    
    # *key_resp_2* updates
    waitOnFlip = False
    
    # if key_resp_2 is starting this frame...
    if key_resp_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        key_resp_2.frameNStart = frameN  # exact frame index
        key_resp_2.tStart = t  # local t and not account for scr refresh
        key_resp_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_2, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'key_resp_2.started')
        # update status
        key_resp_2.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_2.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_2.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_2.getKeys(keyList=['space'], waitRelease=False)
        _key_resp_2_allKeys.extend(theseKeys)
        if len(_key_resp_2_allKeys):
            key_resp_2.keys = _key_resp_2_allKeys[-1].name  # just the last key pressed
            key_resp_2.rt = _key_resp_2_allKeys[-1].rt
            key_resp_2.duration = _key_resp_2_allKeys[-1].duration
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
        if eyetracker:
            eyetracker.setConnectionState(False)
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in welcomeKeyComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "welcomeKey" ---
for thisComponent in welcomeKeyComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if key_resp_2.keys in ['', [], None]:  # No response was made
    key_resp_2.keys = None
thisExp.addData('key_resp_2.keys',key_resp_2.keys)
if key_resp_2.keys != None:  # we had a response
    thisExp.addData('key_resp_2.rt', key_resp_2.rt)
    thisExp.addData('key_resp_2.duration', key_resp_2.duration)
thisExp.nextEntry()
# the Routine "welcomeKey" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# --- Prepare to start Routine "instructions" ---
continueRoutine = True
# update component parameters for each repeat
continue_2.keys = []
continue_2.rt = []
_continue_2_allKeys = []
# keep track of which components have finished
instructionsComponents = [intructionsText, continue_2]
for thisComponent in instructionsComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "instructions" ---
routineForceEnded = not continueRoutine
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *intructionsText* updates
    
    # if intructionsText is starting this frame...
    if intructionsText.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        intructionsText.frameNStart = frameN  # exact frame index
        intructionsText.tStart = t  # local t and not account for scr refresh
        intructionsText.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(intructionsText, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'intructionsText.started')
        # update status
        intructionsText.status = STARTED
        intructionsText.setAutoDraw(True)
    
    # if intructionsText is active this frame...
    if intructionsText.status == STARTED:
        # update params
        pass
    
    # *continue_2* updates
    waitOnFlip = False
    
    # if continue_2 is starting this frame...
    if continue_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        continue_2.frameNStart = frameN  # exact frame index
        continue_2.tStart = t  # local t and not account for scr refresh
        continue_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(continue_2, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'continue_2.started')
        # update status
        continue_2.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(continue_2.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(continue_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if continue_2.status == STARTED and not waitOnFlip:
        theseKeys = continue_2.getKeys(keyList=['space'], waitRelease=False)
        _continue_2_allKeys.extend(theseKeys)
        if len(_continue_2_allKeys):
            continue_2.keys = _continue_2_allKeys[-1].name  # just the last key pressed
            continue_2.rt = _continue_2_allKeys[-1].rt
            continue_2.duration = _continue_2_allKeys[-1].duration
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
        if eyetracker:
            eyetracker.setConnectionState(False)
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in instructionsComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "instructions" ---
for thisComponent in instructionsComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if continue_2.keys in ['', [], None]:  # No response was made
    continue_2.keys = None
thisExp.addData('continue_2.keys',continue_2.keys)
if continue_2.keys != None:  # we had a response
    thisExp.addData('continue_2.rt', continue_2.rt)
    thisExp.addData('continue_2.duration', continue_2.duration)
thisExp.nextEntry()
# the Routine "instructions" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# --- Prepare to start Routine "hands" ---
continueRoutine = True
# update component parameters for each repeat
procede.keys = []
procede.rt = []
_procede_allKeys = []
# keep track of which components have finished
handsComponents = [hand_placement, procede]
for thisComponent in handsComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "hands" ---
routineForceEnded = not continueRoutine
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *hand_placement* updates
    
    # if hand_placement is starting this frame...
    if hand_placement.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        hand_placement.frameNStart = frameN  # exact frame index
        hand_placement.tStart = t  # local t and not account for scr refresh
        hand_placement.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(hand_placement, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'hand_placement.started')
        # update status
        hand_placement.status = STARTED
        hand_placement.setAutoDraw(True)
    
    # if hand_placement is active this frame...
    if hand_placement.status == STARTED:
        # update params
        pass
    
    # *procede* updates
    waitOnFlip = False
    
    # if procede is starting this frame...
    if procede.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        procede.frameNStart = frameN  # exact frame index
        procede.tStart = t  # local t and not account for scr refresh
        procede.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(procede, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'procede.started')
        # update status
        procede.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(procede.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(procede.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if procede.status == STARTED and not waitOnFlip:
        theseKeys = procede.getKeys(keyList=['space'], waitRelease=False)
        _procede_allKeys.extend(theseKeys)
        if len(_procede_allKeys):
            procede.keys = _procede_allKeys[-1].name  # just the last key pressed
            procede.rt = _procede_allKeys[-1].rt
            procede.duration = _procede_allKeys[-1].duration
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
        if eyetracker:
            eyetracker.setConnectionState(False)
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in handsComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "hands" ---
for thisComponent in handsComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if procede.keys in ['', [], None]:  # No response was made
    procede.keys = None
thisExp.addData('procede.keys',procede.keys)
if procede.keys != None:  # we had a response
    thisExp.addData('procede.rt', procede.rt)
    thisExp.addData('procede.duration', procede.duration)
thisExp.nextEntry()
# the Routine "hands" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# --- Prepare to start Routine "three" ---
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
threeComponents = [three_]
for thisComponent in threeComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "three" ---
routineForceEnded = not continueRoutine
while continueRoutine and routineTimer.getTime() < 1.2:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *three_* updates
    
    # if three_ is starting this frame...
    if three_.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        three_.frameNStart = frameN  # exact frame index
        three_.tStart = t  # local t and not account for scr refresh
        three_.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(three_, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'three_.started')
        # update status
        three_.status = STARTED
        three_.setAutoDraw(True)
    
    # if three_ is active this frame...
    if three_.status == STARTED:
        # update params
        pass
    
    # if three_ is stopping this frame...
    if three_.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > three_.tStartRefresh + 1.2-frameTolerance:
            # keep track of stop time/frame for later
            three_.tStop = t  # not accounting for scr refresh
            three_.frameNStop = frameN  # exact frame index
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'three_.stopped')
            # update status
            three_.status = FINISHED
            three_.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
        if eyetracker:
            eyetracker.setConnectionState(False)
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in threeComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "three" ---
for thisComponent in threeComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
if routineForceEnded:
    routineTimer.reset()
else:
    routineTimer.addTime(-1.200000)

# --- Prepare to start Routine "two" ---
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
twoComponents = [two_]
for thisComponent in twoComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "two" ---
routineForceEnded = not continueRoutine
while continueRoutine and routineTimer.getTime() < 1.2:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *two_* updates
    
    # if two_ is starting this frame...
    if two_.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        two_.frameNStart = frameN  # exact frame index
        two_.tStart = t  # local t and not account for scr refresh
        two_.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(two_, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'two_.started')
        # update status
        two_.status = STARTED
        two_.setAutoDraw(True)
    
    # if two_ is active this frame...
    if two_.status == STARTED:
        # update params
        pass
    
    # if two_ is stopping this frame...
    if two_.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > two_.tStartRefresh + 1.2-frameTolerance:
            # keep track of stop time/frame for later
            two_.tStop = t  # not accounting for scr refresh
            two_.frameNStop = frameN  # exact frame index
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'two_.stopped')
            # update status
            two_.status = FINISHED
            two_.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
        if eyetracker:
            eyetracker.setConnectionState(False)
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in twoComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "two" ---
for thisComponent in twoComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
if routineForceEnded:
    routineTimer.reset()
else:
    routineTimer.addTime(-1.200000)

# --- Prepare to start Routine "one" ---
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
oneComponents = [one_]
for thisComponent in oneComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "one" ---
routineForceEnded = not continueRoutine
while continueRoutine and routineTimer.getTime() < 1.2:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *one_* updates
    
    # if one_ is starting this frame...
    if one_.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        one_.frameNStart = frameN  # exact frame index
        one_.tStart = t  # local t and not account for scr refresh
        one_.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(one_, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'one_.started')
        # update status
        one_.status = STARTED
        one_.setAutoDraw(True)
    
    # if one_ is active this frame...
    if one_.status == STARTED:
        # update params
        pass
    
    # if one_ is stopping this frame...
    if one_.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > one_.tStartRefresh + 1.2-frameTolerance:
            # keep track of stop time/frame for later
            one_.tStop = t  # not accounting for scr refresh
            one_.frameNStop = frameN  # exact frame index
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'one_.stopped')
            # update status
            one_.status = FINISHED
            one_.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
        if eyetracker:
            eyetracker.setConnectionState(False)
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in oneComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "one" ---
for thisComponent in oneComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
if routineForceEnded:
    routineTimer.reset()
else:
    routineTimer.addTime(-1.200000)

# --- Prepare to start Routine "zero" ---
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
zeroComponents = [zero_]
for thisComponent in zeroComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "zero" ---
routineForceEnded = not continueRoutine
while continueRoutine and routineTimer.getTime() < 1.0:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *zero_* updates
    
    # if zero_ is starting this frame...
    if zero_.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        zero_.frameNStart = frameN  # exact frame index
        zero_.tStart = t  # local t and not account for scr refresh
        zero_.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(zero_, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'zero_.started')
        # update status
        zero_.status = STARTED
        zero_.setAutoDraw(True)
    
    # if zero_ is active this frame...
    if zero_.status == STARTED:
        # update params
        pass
    
    # if zero_ is stopping this frame...
    if zero_.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > zero_.tStartRefresh + 1.0-frameTolerance:
            # keep track of stop time/frame for later
            zero_.tStop = t  # not accounting for scr refresh
            zero_.frameNStop = frameN  # exact frame index
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'zero_.stopped')
            # update status
            zero_.status = FINISHED
            zero_.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
        if eyetracker:
            eyetracker.setConnectionState(False)
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in zeroComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "zero" ---
for thisComponent in zeroComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
if routineForceEnded:
    routineTimer.reset()
else:
    routineTimer.addTime(-1.000000)

# set up handler to look after randomisation of conditions etc
practice_loop = data.TrialHandler(nReps=1.0, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('resources/practice_conditions_df.csv'),
    seed=None, name='practice_loop')
thisExp.addLoop(practice_loop)  # add the loop to the experiment
thisPractice_loop = practice_loop.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisPractice_loop.rgb)
if thisPractice_loop != None:
    for paramName in thisPractice_loop:
        exec('{} = thisPractice_loop[paramName]'.format(paramName))

for thisPractice_loop in practice_loop:
    currentLoop = practice_loop
    # abbreviate parameter names if possible (e.g. rgb = thisPractice_loop.rgb)
    if thisPractice_loop != None:
        for paramName in thisPractice_loop:
            exec('{} = thisPractice_loop[paramName]'.format(paramName))
    
    # set up handler to look after randomisation of conditions etc
    show_target_curve_practice = data.TrialHandler(nReps=show_target, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='show_target_curve_practice')
    thisExp.addLoop(show_target_curve_practice)  # add the loop to the experiment
    thisShow_target_curve_practice = show_target_curve_practice.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisShow_target_curve_practice.rgb)
    if thisShow_target_curve_practice != None:
        for paramName in thisShow_target_curve_practice:
            exec('{} = thisShow_target_curve_practice[paramName]'.format(paramName))
    
    for thisShow_target_curve_practice in show_target_curve_practice:
        currentLoop = show_target_curve_practice
        # abbreviate parameter names if possible (e.g. rgb = thisShow_target_curve_practice.rgb)
        if thisShow_target_curve_practice != None:
            for paramName in thisShow_target_curve_practice:
                exec('{} = thisShow_target_curve_practice[paramName]'.format(paramName))
        
        # --- Prepare to start Routine "warningBluePractice" ---
        continueRoutine = True
        # update component parameters for each repeat
        # keep track of which components have finished
        warningBluePracticeComponents = [warningBluePract, practicePreTargetTxt]
        for thisComponent in warningBluePracticeComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "warningBluePractice" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 2.0:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *warningBluePract* updates
            
            # if warningBluePract is starting this frame...
            if warningBluePract.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                warningBluePract.frameNStart = frameN  # exact frame index
                warningBluePract.tStart = t  # local t and not account for scr refresh
                warningBluePract.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(warningBluePract, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'warningBluePract.started')
                # update status
                warningBluePract.status = STARTED
                warningBluePract.setAutoDraw(True)
            
            # if warningBluePract is active this frame...
            if warningBluePract.status == STARTED:
                # update params
                pass
            
            # if warningBluePract is stopping this frame...
            if warningBluePract.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > warningBluePract.tStartRefresh + 2-frameTolerance:
                    # keep track of stop time/frame for later
                    warningBluePract.tStop = t  # not accounting for scr refresh
                    warningBluePract.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'warningBluePract.stopped')
                    # update status
                    warningBluePract.status = FINISHED
                    warningBluePract.setAutoDraw(False)
            
            # *practicePreTargetTxt* updates
            
            # if practicePreTargetTxt is starting this frame...
            if practicePreTargetTxt.status == NOT_STARTED and tThisFlip >= .5-frameTolerance:
                # keep track of start time/frame for later
                practicePreTargetTxt.frameNStart = frameN  # exact frame index
                practicePreTargetTxt.tStart = t  # local t and not account for scr refresh
                practicePreTargetTxt.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(practicePreTargetTxt, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'practicePreTargetTxt.started')
                # update status
                practicePreTargetTxt.status = STARTED
                practicePreTargetTxt.setAutoDraw(True)
            
            # if practicePreTargetTxt is active this frame...
            if practicePreTargetTxt.status == STARTED:
                # update params
                pass
            
            # if practicePreTargetTxt is stopping this frame...
            if practicePreTargetTxt.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > practicePreTargetTxt.tStartRefresh + 1-frameTolerance:
                    # keep track of stop time/frame for later
                    practicePreTargetTxt.tStop = t  # not accounting for scr refresh
                    practicePreTargetTxt.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'practicePreTargetTxt.stopped')
                    # update status
                    practicePreTargetTxt.status = FINISHED
                    practicePreTargetTxt.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
                if eyetracker:
                    eyetracker.setConnectionState(False)
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in warningBluePracticeComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "warningBluePractice" ---
        for thisComponent in warningBluePracticeComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-2.000000)
        
        # --- Prepare to start Routine "practiceTarget" ---
        continueRoutine = True
        # update component parameters for each repeat
        practiceTargetImg.setImage(target_file)
        practiceTargetText.setText('\n')
        # keep track of which components have finished
        practiceTargetComponents = [practiceTargetImg, practiceTargetText]
        for thisComponent in practiceTargetComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "practiceTarget" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 3.0:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *practiceTargetImg* updates
            
            # if practiceTargetImg is starting this frame...
            if practiceTargetImg.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                practiceTargetImg.frameNStart = frameN  # exact frame index
                practiceTargetImg.tStart = t  # local t and not account for scr refresh
                practiceTargetImg.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(practiceTargetImg, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'practiceTargetImg.started')
                # update status
                practiceTargetImg.status = STARTED
                practiceTargetImg.setAutoDraw(True)
            
            # if practiceTargetImg is active this frame...
            if practiceTargetImg.status == STARTED:
                # update params
                pass
            
            # if practiceTargetImg is stopping this frame...
            if practiceTargetImg.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > practiceTargetImg.tStartRefresh + 3-frameTolerance:
                    # keep track of stop time/frame for later
                    practiceTargetImg.tStop = t  # not accounting for scr refresh
                    practiceTargetImg.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'practiceTargetImg.stopped')
                    # update status
                    practiceTargetImg.status = FINISHED
                    practiceTargetImg.setAutoDraw(False)
            
            # *practiceTargetText* updates
            
            # if practiceTargetText is starting this frame...
            if practiceTargetText.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                practiceTargetText.frameNStart = frameN  # exact frame index
                practiceTargetText.tStart = t  # local t and not account for scr refresh
                practiceTargetText.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(practiceTargetText, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'practiceTargetText.started')
                # update status
                practiceTargetText.status = STARTED
                practiceTargetText.setAutoDraw(True)
            
            # if practiceTargetText is active this frame...
            if practiceTargetText.status == STARTED:
                # update params
                pass
            
            # if practiceTargetText is stopping this frame...
            if practiceTargetText.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > practiceTargetText.tStartRefresh + 3-frameTolerance:
                    # keep track of stop time/frame for later
                    practiceTargetText.tStop = t  # not accounting for scr refresh
                    practiceTargetText.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'practiceTargetText.stopped')
                    # update status
                    practiceTargetText.status = FINISHED
                    practiceTargetText.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
                if eyetracker:
                    eyetracker.setConnectionState(False)
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in practiceTargetComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "practiceTarget" ---
        for thisComponent in practiceTargetComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-3.000000)
        
        # --- Prepare to start Routine "pause" ---
        continueRoutine = True
        # update component parameters for each repeat
        # keep track of which components have finished
        pauseComponents = [blank_img2]
        for thisComponent in pauseComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "pause" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 0.2:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *blank_img2* updates
            
            # if blank_img2 is starting this frame...
            if blank_img2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                blank_img2.frameNStart = frameN  # exact frame index
                blank_img2.tStart = t  # local t and not account for scr refresh
                blank_img2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(blank_img2, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'blank_img2.started')
                # update status
                blank_img2.status = STARTED
                blank_img2.setAutoDraw(True)
            
            # if blank_img2 is active this frame...
            if blank_img2.status == STARTED:
                # update params
                pass
            
            # if blank_img2 is stopping this frame...
            if blank_img2.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > blank_img2.tStartRefresh + .2-frameTolerance:
                    # keep track of stop time/frame for later
                    blank_img2.tStop = t  # not accounting for scr refresh
                    blank_img2.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'blank_img2.stopped')
                    # update status
                    blank_img2.status = FINISHED
                    blank_img2.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
                if eyetracker:
                    eyetracker.setConnectionState(False)
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in pauseComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "pause" ---
        for thisComponent in pauseComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-0.200000)
    # completed show_target repeats of 'show_target_curve_practice'
    
    
    # --- Prepare to start Routine "isi" ---
    continueRoutine = True
    # update component parameters for each repeat
    # keep track of which components have finished
    isiComponents = [blank_img]
    for thisComponent in isiComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "isi" ---
    routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 0.5:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *blank_img* updates
        
        # if blank_img is starting this frame...
        if blank_img.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            blank_img.frameNStart = frameN  # exact frame index
            blank_img.tStart = t  # local t and not account for scr refresh
            blank_img.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(blank_img, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'blank_img.started')
            # update status
            blank_img.status = STARTED
            blank_img.setAutoDraw(True)
        
        # if blank_img is active this frame...
        if blank_img.status == STARTED:
            # update params
            pass
        
        # if blank_img is stopping this frame...
        if blank_img.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > blank_img.tStartRefresh + .5-frameTolerance:
                # keep track of stop time/frame for later
                blank_img.tStop = t  # not accounting for scr refresh
                blank_img.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'blank_img.stopped')
                # update status
                blank_img.status = FINISHED
                blank_img.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
            if eyetracker:
                eyetracker.setConnectionState(False)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in isiComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "isi" ---
    for thisComponent in isiComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-0.500000)
    
    # --- Prepare to start Routine "practiceProbe" ---
    continueRoutine = True
    # update component parameters for each repeat
    practiceResponse.keys = []
    practiceResponse.rt = []
    _practiceResponse_allKeys = []
    practiceProbeImg.setImage(probe_file)
    practiceProbeText.setText(comparator)
    # keep track of which components have finished
    practiceProbeComponents = [practiceResponse, practiceProbeImg, practiceProbeText]
    for thisComponent in practiceProbeComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "practiceProbe" ---
    routineForceEnded = not continueRoutine
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *practiceResponse* updates
        waitOnFlip = False
        
        # if practiceResponse is starting this frame...
        if practiceResponse.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            practiceResponse.frameNStart = frameN  # exact frame index
            practiceResponse.tStart = t  # local t and not account for scr refresh
            practiceResponse.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(practiceResponse, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'practiceResponse.started')
            # update status
            practiceResponse.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(practiceResponse.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(practiceResponse.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if practiceResponse.status == STARTED and not waitOnFlip:
            theseKeys = practiceResponse.getKeys(keyList=['right', 'left'], waitRelease=False)
            _practiceResponse_allKeys.extend(theseKeys)
            if len(_practiceResponse_allKeys):
                practiceResponse.keys = _practiceResponse_allKeys[-1].name  # just the last key pressed
                practiceResponse.rt = _practiceResponse_allKeys[-1].rt
                practiceResponse.duration = _practiceResponse_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # *practiceProbeImg* updates
        
        # if practiceProbeImg is starting this frame...
        if practiceProbeImg.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            practiceProbeImg.frameNStart = frameN  # exact frame index
            practiceProbeImg.tStart = t  # local t and not account for scr refresh
            practiceProbeImg.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(practiceProbeImg, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'practiceProbeImg.started')
            # update status
            practiceProbeImg.status = STARTED
            practiceProbeImg.setAutoDraw(True)
        
        # if practiceProbeImg is active this frame...
        if practiceProbeImg.status == STARTED:
            # update params
            pass
        
        # *practiceProbeText* updates
        
        # if practiceProbeText is starting this frame...
        if practiceProbeText.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            practiceProbeText.frameNStart = frameN  # exact frame index
            practiceProbeText.tStart = t  # local t and not account for scr refresh
            practiceProbeText.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(practiceProbeText, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'practiceProbeText.started')
            # update status
            practiceProbeText.status = STARTED
            practiceProbeText.setAutoDraw(True)
        
        # if practiceProbeText is active this frame...
        if practiceProbeText.status == STARTED:
            # update params
            pass
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
            if eyetracker:
                eyetracker.setConnectionState(False)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in practiceProbeComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "practiceProbe" ---
    for thisComponent in practiceProbeComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if practiceResponse.keys in ['', [], None]:  # No response was made
        practiceResponse.keys = None
    practice_loop.addData('practiceResponse.keys',practiceResponse.keys)
    if practiceResponse.keys != None:  # we had a response
        practice_loop.addData('practiceResponse.rt', practiceResponse.rt)
        practice_loop.addData('practiceResponse.duration', practiceResponse.duration)
    # Run 'End Routine' code from code
    if practiceResponse.keys == correct_resp:
        isCorrect = 1
        isIncorrect = 0
    else:
        isCorrect = 0
        isIncorrect = 1    
    #if int(show_target) == 0:
    #    txt = 'Use the key pad to answer: how many times does this pink line intersect the curve you just saw?'
    #else:
    #    txt = 'Repeat'
    # the Routine "practiceProbe" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    correct = data.TrialHandler(nReps=isCorrect, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='correct')
    thisExp.addLoop(correct)  # add the loop to the experiment
    thisCorrect = correct.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisCorrect.rgb)
    if thisCorrect != None:
        for paramName in thisCorrect:
            exec('{} = thisCorrect[paramName]'.format(paramName))
    
    for thisCorrect in correct:
        currentLoop = correct
        # abbreviate parameter names if possible (e.g. rgb = thisCorrect.rgb)
        if thisCorrect != None:
            for paramName in thisCorrect:
                exec('{} = thisCorrect[paramName]'.format(paramName))
        
        # --- Prepare to start Routine "practiceFeedbackCorrect" ---
        continueRoutine = True
        # update component parameters for each repeat
        showIsecsCorrect.setImage(isecs_image)
        # keep track of which components have finished
        practiceFeedbackCorrectComponents = [showIsecsCorrect, text_2]
        for thisComponent in practiceFeedbackCorrectComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "practiceFeedbackCorrect" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 3.0:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *showIsecsCorrect* updates
            
            # if showIsecsCorrect is starting this frame...
            if showIsecsCorrect.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                showIsecsCorrect.frameNStart = frameN  # exact frame index
                showIsecsCorrect.tStart = t  # local t and not account for scr refresh
                showIsecsCorrect.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(showIsecsCorrect, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'showIsecsCorrect.started')
                # update status
                showIsecsCorrect.status = STARTED
                showIsecsCorrect.setAutoDraw(True)
            
            # if showIsecsCorrect is active this frame...
            if showIsecsCorrect.status == STARTED:
                # update params
                pass
            
            # if showIsecsCorrect is stopping this frame...
            if showIsecsCorrect.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > showIsecsCorrect.tStartRefresh + 3-frameTolerance:
                    # keep track of stop time/frame for later
                    showIsecsCorrect.tStop = t  # not accounting for scr refresh
                    showIsecsCorrect.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'showIsecsCorrect.stopped')
                    # update status
                    showIsecsCorrect.status = FINISHED
                    showIsecsCorrect.setAutoDraw(False)
            
            # *text_2* updates
            
            # if text_2 is starting this frame...
            if text_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_2.frameNStart = frameN  # exact frame index
                text_2.tStart = t  # local t and not account for scr refresh
                text_2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_2, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_2.started')
                # update status
                text_2.status = STARTED
                text_2.setAutoDraw(True)
            
            # if text_2 is active this frame...
            if text_2.status == STARTED:
                # update params
                pass
            
            # if text_2 is stopping this frame...
            if text_2.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_2.tStartRefresh + 3-frameTolerance:
                    # keep track of stop time/frame for later
                    text_2.tStop = t  # not accounting for scr refresh
                    text_2.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_2.stopped')
                    # update status
                    text_2.status = FINISHED
                    text_2.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
                if eyetracker:
                    eyetracker.setConnectionState(False)
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in practiceFeedbackCorrectComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "practiceFeedbackCorrect" ---
        for thisComponent in practiceFeedbackCorrectComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-3.000000)
    # completed isCorrect repeats of 'correct'
    
    
    # set up handler to look after randomisation of conditions etc
    incorrect = data.TrialHandler(nReps=isIncorrect, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='incorrect')
    thisExp.addLoop(incorrect)  # add the loop to the experiment
    thisIncorrect = incorrect.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisIncorrect.rgb)
    if thisIncorrect != None:
        for paramName in thisIncorrect:
            exec('{} = thisIncorrect[paramName]'.format(paramName))
    
    for thisIncorrect in incorrect:
        currentLoop = incorrect
        # abbreviate parameter names if possible (e.g. rgb = thisIncorrect.rgb)
        if thisIncorrect != None:
            for paramName in thisIncorrect:
                exec('{} = thisIncorrect[paramName]'.format(paramName))
        
        # --- Prepare to start Routine "practiceFeedbackIncorrect" ---
        continueRoutine = True
        # update component parameters for each repeat
        showIsecsIncorrect.setImage(isecs_image)
        # keep track of which components have finished
        practiceFeedbackIncorrectComponents = [showIsecsIncorrect, incorrectText]
        for thisComponent in practiceFeedbackIncorrectComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "practiceFeedbackIncorrect" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 3.0:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *showIsecsIncorrect* updates
            
            # if showIsecsIncorrect is starting this frame...
            if showIsecsIncorrect.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                showIsecsIncorrect.frameNStart = frameN  # exact frame index
                showIsecsIncorrect.tStart = t  # local t and not account for scr refresh
                showIsecsIncorrect.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(showIsecsIncorrect, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'showIsecsIncorrect.started')
                # update status
                showIsecsIncorrect.status = STARTED
                showIsecsIncorrect.setAutoDraw(True)
            
            # if showIsecsIncorrect is active this frame...
            if showIsecsIncorrect.status == STARTED:
                # update params
                pass
            
            # if showIsecsIncorrect is stopping this frame...
            if showIsecsIncorrect.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > showIsecsIncorrect.tStartRefresh + 3-frameTolerance:
                    # keep track of stop time/frame for later
                    showIsecsIncorrect.tStop = t  # not accounting for scr refresh
                    showIsecsIncorrect.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'showIsecsIncorrect.stopped')
                    # update status
                    showIsecsIncorrect.status = FINISHED
                    showIsecsIncorrect.setAutoDraw(False)
            
            # *incorrectText* updates
            
            # if incorrectText is starting this frame...
            if incorrectText.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                incorrectText.frameNStart = frameN  # exact frame index
                incorrectText.tStart = t  # local t and not account for scr refresh
                incorrectText.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(incorrectText, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'incorrectText.started')
                # update status
                incorrectText.status = STARTED
                incorrectText.setAutoDraw(True)
            
            # if incorrectText is active this frame...
            if incorrectText.status == STARTED:
                # update params
                pass
            
            # if incorrectText is stopping this frame...
            if incorrectText.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > incorrectText.tStartRefresh + 3-frameTolerance:
                    # keep track of stop time/frame for later
                    incorrectText.tStop = t  # not accounting for scr refresh
                    incorrectText.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'incorrectText.stopped')
                    # update status
                    incorrectText.status = FINISHED
                    incorrectText.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
                if eyetracker:
                    eyetracker.setConnectionState(False)
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in practiceFeedbackIncorrectComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "practiceFeedbackIncorrect" ---
        for thisComponent in practiceFeedbackIncorrectComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-3.000000)
    # completed isIncorrect repeats of 'incorrect'
    
# completed 1.0 repeats of 'practice_loop'


# --- Prepare to start Routine "begin" ---
continueRoutine = True
# update component parameters for each repeat
begin_exp.keys = []
begin_exp.rt = []
_begin_exp_allKeys = []
# keep track of which components have finished
beginComponents = [text, begin_exp]
for thisComponent in beginComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "begin" ---
routineForceEnded = not continueRoutine
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text* updates
    
    # if text is starting this frame...
    if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text.frameNStart = frameN  # exact frame index
        text.tStart = t  # local t and not account for scr refresh
        text.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'text.started')
        # update status
        text.status = STARTED
        text.setAutoDraw(True)
    
    # if text is active this frame...
    if text.status == STARTED:
        # update params
        pass
    
    # *begin_exp* updates
    waitOnFlip = False
    
    # if begin_exp is starting this frame...
    if begin_exp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        begin_exp.frameNStart = frameN  # exact frame index
        begin_exp.tStart = t  # local t and not account for scr refresh
        begin_exp.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(begin_exp, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'begin_exp.started')
        # update status
        begin_exp.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(begin_exp.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(begin_exp.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if begin_exp.status == STARTED and not waitOnFlip:
        theseKeys = begin_exp.getKeys(keyList=['space'], waitRelease=False)
        _begin_exp_allKeys.extend(theseKeys)
        if len(_begin_exp_allKeys):
            begin_exp.keys = _begin_exp_allKeys[-1].name  # just the last key pressed
            begin_exp.rt = _begin_exp_allKeys[-1].rt
            begin_exp.duration = _begin_exp_allKeys[-1].duration
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
        if eyetracker:
            eyetracker.setConnectionState(False)
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in beginComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "begin" ---
for thisComponent in beginComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if begin_exp.keys in ['', [], None]:  # No response was made
    begin_exp.keys = None
thisExp.addData('begin_exp.keys',begin_exp.keys)
if begin_exp.keys != None:  # we had a response
    thisExp.addData('begin_exp.rt', begin_exp.rt)
    thisExp.addData('begin_exp.duration', begin_exp.duration)
thisExp.nextEntry()
# the Routine "begin" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
trials = data.TrialHandler(nReps=1.0, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('resources/conditions_df.csv'),
    seed=1, name='trials')
thisExp.addLoop(trials)  # add the loop to the experiment
thisTrial = trials.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
if thisTrial != None:
    for paramName in thisTrial:
        exec('{} = thisTrial[paramName]'.format(paramName))

for thisTrial in trials:
    currentLoop = trials
    # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
    if thisTrial != None:
        for paramName in thisTrial:
            exec('{} = thisTrial[paramName]'.format(paramName))
    
    # set up handler to look after randomisation of conditions etc
    show_target_curve = data.TrialHandler(nReps=show_target, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='show_target_curve')
    thisExp.addLoop(show_target_curve)  # add the loop to the experiment
    thisShow_target_curve = show_target_curve.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisShow_target_curve.rgb)
    if thisShow_target_curve != None:
        for paramName in thisShow_target_curve:
            exec('{} = thisShow_target_curve[paramName]'.format(paramName))
    
    for thisShow_target_curve in show_target_curve:
        currentLoop = show_target_curve
        # abbreviate parameter names if possible (e.g. rgb = thisShow_target_curve.rgb)
        if thisShow_target_curve != None:
            for paramName in thisShow_target_curve:
                exec('{} = thisShow_target_curve[paramName]'.format(paramName))
        
        # --- Prepare to start Routine "warningBlue" ---
        continueRoutine = True
        # update component parameters for each repeat
        # keep track of which components have finished
        warningBlueComponents = [blank_500_red, memory_reminder]
        for thisComponent in warningBlueComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "warningBlue" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 2.0:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *blank_500_red* updates
            
            # if blank_500_red is starting this frame...
            if blank_500_red.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                blank_500_red.frameNStart = frameN  # exact frame index
                blank_500_red.tStart = t  # local t and not account for scr refresh
                blank_500_red.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(blank_500_red, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'blank_500_red.started')
                # update status
                blank_500_red.status = STARTED
                blank_500_red.setAutoDraw(True)
            
            # if blank_500_red is active this frame...
            if blank_500_red.status == STARTED:
                # update params
                pass
            
            # if blank_500_red is stopping this frame...
            if blank_500_red.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > blank_500_red.tStartRefresh + 2-frameTolerance:
                    # keep track of stop time/frame for later
                    blank_500_red.tStop = t  # not accounting for scr refresh
                    blank_500_red.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'blank_500_red.stopped')
                    # update status
                    blank_500_red.status = FINISHED
                    blank_500_red.setAutoDraw(False)
            
            # *memory_reminder* updates
            
            # if memory_reminder is starting this frame...
            if memory_reminder.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                memory_reminder.frameNStart = frameN  # exact frame index
                memory_reminder.tStart = t  # local t and not account for scr refresh
                memory_reminder.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(memory_reminder, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'memory_reminder.started')
                # update status
                memory_reminder.status = STARTED
                memory_reminder.setAutoDraw(True)
            
            # if memory_reminder is active this frame...
            if memory_reminder.status == STARTED:
                # update params
                pass
            
            # if memory_reminder is stopping this frame...
            if memory_reminder.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > memory_reminder.tStartRefresh + 1.0-frameTolerance:
                    # keep track of stop time/frame for later
                    memory_reminder.tStop = t  # not accounting for scr refresh
                    memory_reminder.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'memory_reminder.stopped')
                    # update status
                    memory_reminder.status = FINISHED
                    memory_reminder.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
                if eyetracker:
                    eyetracker.setConnectionState(False)
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in warningBlueComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "warningBlue" ---
        for thisComponent in warningBlueComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-2.000000)
        
        # --- Prepare to start Routine "target" ---
        continueRoutine = True
        # update component parameters for each repeat
        target_img.setImage(target_file)
        # keep track of which components have finished
        targetComponents = [target_img]
        for thisComponent in targetComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "target" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 2.8:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *target_img* updates
            
            # if target_img is starting this frame...
            if target_img.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                target_img.frameNStart = frameN  # exact frame index
                target_img.tStart = t  # local t and not account for scr refresh
                target_img.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(target_img, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'target_img.started')
                # update status
                target_img.status = STARTED
                target_img.setAutoDraw(True)
            
            # if target_img is active this frame...
            if target_img.status == STARTED:
                # update params
                pass
            
            # if target_img is stopping this frame...
            if target_img.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > target_img.tStartRefresh + 2.8-frameTolerance:
                    # keep track of stop time/frame for later
                    target_img.tStop = t  # not accounting for scr refresh
                    target_img.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'target_img.stopped')
                    # update status
                    target_img.status = FINISHED
                    target_img.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
                if eyetracker:
                    eyetracker.setConnectionState(False)
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in targetComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "target" ---
        for thisComponent in targetComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-2.800000)
        
        # --- Prepare to start Routine "pause" ---
        continueRoutine = True
        # update component parameters for each repeat
        # keep track of which components have finished
        pauseComponents = [blank_img2]
        for thisComponent in pauseComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "pause" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 0.2:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *blank_img2* updates
            
            # if blank_img2 is starting this frame...
            if blank_img2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                blank_img2.frameNStart = frameN  # exact frame index
                blank_img2.tStart = t  # local t and not account for scr refresh
                blank_img2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(blank_img2, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'blank_img2.started')
                # update status
                blank_img2.status = STARTED
                blank_img2.setAutoDraw(True)
            
            # if blank_img2 is active this frame...
            if blank_img2.status == STARTED:
                # update params
                pass
            
            # if blank_img2 is stopping this frame...
            if blank_img2.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > blank_img2.tStartRefresh + .2-frameTolerance:
                    # keep track of stop time/frame for later
                    blank_img2.tStop = t  # not accounting for scr refresh
                    blank_img2.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'blank_img2.stopped')
                    # update status
                    blank_img2.status = FINISHED
                    blank_img2.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
                if eyetracker:
                    eyetracker.setConnectionState(False)
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in pauseComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "pause" ---
        for thisComponent in pauseComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-0.200000)
    # completed show_target repeats of 'show_target_curve'
    
    
    # --- Prepare to start Routine "isi" ---
    continueRoutine = True
    # update component parameters for each repeat
    # keep track of which components have finished
    isiComponents = [blank_img]
    for thisComponent in isiComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "isi" ---
    routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 0.5:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *blank_img* updates
        
        # if blank_img is starting this frame...
        if blank_img.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            blank_img.frameNStart = frameN  # exact frame index
            blank_img.tStart = t  # local t and not account for scr refresh
            blank_img.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(blank_img, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'blank_img.started')
            # update status
            blank_img.status = STARTED
            blank_img.setAutoDraw(True)
        
        # if blank_img is active this frame...
        if blank_img.status == STARTED:
            # update params
            pass
        
        # if blank_img is stopping this frame...
        if blank_img.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > blank_img.tStartRefresh + .5-frameTolerance:
                # keep track of stop time/frame for later
                blank_img.tStop = t  # not accounting for scr refresh
                blank_img.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'blank_img.stopped')
                # update status
                blank_img.status = FINISHED
                blank_img.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
            if eyetracker:
                eyetracker.setConnectionState(False)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in isiComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "isi" ---
    for thisComponent in isiComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-0.500000)
    
    # --- Prepare to start Routine "probe" ---
    continueRoutine = True
    # update component parameters for each repeat
    probeCurve.setImage(probe_file)
    key_resp.keys = []
    key_resp.rt = []
    _key_resp_allKeys = []
    comp.setText(comparator)
    # keep track of which components have finished
    probeComponents = [probeCurve, key_resp, comp]
    for thisComponent in probeComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "probe" ---
    routineForceEnded = not continueRoutine
    while continueRoutine and routineTimer.getTime() < 10.0:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *probeCurve* updates
        
        # if probeCurve is starting this frame...
        if probeCurve.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            probeCurve.frameNStart = frameN  # exact frame index
            probeCurve.tStart = t  # local t and not account for scr refresh
            probeCurve.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(probeCurve, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'probeCurve.started')
            # update status
            probeCurve.status = STARTED
            probeCurve.setAutoDraw(True)
        
        # if probeCurve is active this frame...
        if probeCurve.status == STARTED:
            # update params
            pass
        
        # if probeCurve is stopping this frame...
        if probeCurve.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > probeCurve.tStartRefresh + 10-frameTolerance:
                # keep track of stop time/frame for later
                probeCurve.tStop = t  # not accounting for scr refresh
                probeCurve.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'probeCurve.stopped')
                # update status
                probeCurve.status = FINISHED
                probeCurve.setAutoDraw(False)
        
        # *key_resp* updates
        waitOnFlip = False
        
        # if key_resp is starting this frame...
        if key_resp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            key_resp.frameNStart = frameN  # exact frame index
            key_resp.tStart = t  # local t and not account for scr refresh
            key_resp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(key_resp, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'key_resp.started')
            # update status
            key_resp.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(key_resp.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
        
        # if key_resp is stopping this frame...
        if key_resp.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > key_resp.tStartRefresh + 10-frameTolerance:
                # keep track of stop time/frame for later
                key_resp.tStop = t  # not accounting for scr refresh
                key_resp.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp.stopped')
                # update status
                key_resp.status = FINISHED
                key_resp.status = FINISHED
        if key_resp.status == STARTED and not waitOnFlip:
            theseKeys = key_resp.getKeys(keyList=['left', 'right'], waitRelease=False)
            _key_resp_allKeys.extend(theseKeys)
            if len(_key_resp_allKeys):
                key_resp.keys = _key_resp_allKeys[-1].name  # just the last key pressed
                key_resp.rt = _key_resp_allKeys[-1].rt
                key_resp.duration = _key_resp_allKeys[-1].duration
                # a response ends the routine
                continueRoutine = False
        
        # *comp* updates
        
        # if comp is starting this frame...
        if comp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            comp.frameNStart = frameN  # exact frame index
            comp.tStart = t  # local t and not account for scr refresh
            comp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(comp, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'comp.started')
            # update status
            comp.status = STARTED
            comp.setAutoDraw(True)
        
        # if comp is active this frame...
        if comp.status == STARTED:
            # update params
            pass
        
        # if comp is stopping this frame...
        if comp.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > comp.tStartRefresh + 10-frameTolerance:
                # keep track of stop time/frame for later
                comp.tStop = t  # not accounting for scr refresh
                comp.frameNStop = frameN  # exact frame index
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'comp.stopped')
                # update status
                comp.status = FINISHED
                comp.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
            if eyetracker:
                eyetracker.setConnectionState(False)
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in probeComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "probe" ---
    for thisComponent in probeComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # check responses
    if key_resp.keys in ['', [], None]:  # No response was made
        key_resp.keys = None
    trials.addData('key_resp.keys',key_resp.keys)
    if key_resp.keys != None:  # we had a response
        trials.addData('key_resp.rt', key_resp.rt)
        trials.addData('key_resp.duration', key_resp.duration)
    # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
    if routineForceEnded:
        routineTimer.reset()
    else:
        routineTimer.addTime(-10.000000)
    
    # set up handler to look after randomisation of conditions etc
    show_break_loop = data.TrialHandler(nReps=show_break, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='show_break_loop')
    thisExp.addLoop(show_break_loop)  # add the loop to the experiment
    thisShow_break_loop = show_break_loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisShow_break_loop.rgb)
    if thisShow_break_loop != None:
        for paramName in thisShow_break_loop:
            exec('{} = thisShow_break_loop[paramName]'.format(paramName))
    
    for thisShow_break_loop in show_break_loop:
        currentLoop = show_break_loop
        # abbreviate parameter names if possible (e.g. rgb = thisShow_break_loop.rgb)
        if thisShow_break_loop != None:
            for paramName in thisShow_break_loop:
                exec('{} = thisShow_break_loop[paramName]'.format(paramName))
        
        # --- Prepare to start Routine "takeBreak" ---
        continueRoutine = True
        # update component parameters for each repeat
        rest.setText("block " + str(block) + " done\n\n" + "Take a break\n\n" + "(90 seconds)" )
        # keep track of which components have finished
        takeBreakComponents = [rest]
        for thisComponent in takeBreakComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "takeBreak" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 90.0:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *rest* updates
            
            # if rest is starting this frame...
            if rest.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                rest.frameNStart = frameN  # exact frame index
                rest.tStart = t  # local t and not account for scr refresh
                rest.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(rest, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'rest.started')
                # update status
                rest.status = STARTED
                rest.setAutoDraw(True)
            
            # if rest is active this frame...
            if rest.status == STARTED:
                # update params
                pass
            
            # if rest is stopping this frame...
            if rest.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > rest.tStartRefresh + 90 -frameTolerance:
                    # keep track of stop time/frame for later
                    rest.tStop = t  # not accounting for scr refresh
                    rest.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'rest.stopped')
                    # update status
                    rest.status = FINISHED
                    rest.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
                if eyetracker:
                    eyetracker.setConnectionState(False)
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in takeBreakComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "takeBreak" ---
        for thisComponent in takeBreakComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-90.000000)
        
        # --- Prepare to start Routine "getReady" ---
        continueRoutine = True
        # update component parameters for each repeat
        # keep track of which components have finished
        getReadyComponents = [ready]
        for thisComponent in getReadyComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "getReady" ---
        routineForceEnded = not continueRoutine
        while continueRoutine and routineTimer.getTime() < 10.0:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *ready* updates
            
            # if ready is starting this frame...
            if ready.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                ready.frameNStart = frameN  # exact frame index
                ready.tStart = t  # local t and not account for scr refresh
                ready.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(ready, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'ready.started')
                # update status
                ready.status = STARTED
                ready.setAutoDraw(True)
            
            # if ready is active this frame...
            if ready.status == STARTED:
                # update params
                pass
            
            # if ready is stopping this frame...
            if ready.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > ready.tStartRefresh + 10.0-frameTolerance:
                    # keep track of stop time/frame for later
                    ready.tStop = t  # not accounting for scr refresh
                    ready.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'ready.stopped')
                    # update status
                    ready.status = FINISHED
                    ready.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
                if eyetracker:
                    eyetracker.setConnectionState(False)
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in getReadyComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "getReady" ---
        for thisComponent in getReadyComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-10.000000)
    # completed show_break repeats of 'show_break_loop'
    
    thisExp.nextEntry()
    
# completed 1.0 repeats of 'trials'


# --- Prepare to start Routine "exit" ---
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
exitComponents = [goodbyeText]
for thisComponent in exitComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "exit" ---
routineForceEnded = not continueRoutine
while continueRoutine and routineTimer.getTime() < 3.0:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *goodbyeText* updates
    
    # if goodbyeText is starting this frame...
    if goodbyeText.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        goodbyeText.frameNStart = frameN  # exact frame index
        goodbyeText.tStart = t  # local t and not account for scr refresh
        goodbyeText.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(goodbyeText, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'goodbyeText.started')
        # update status
        goodbyeText.status = STARTED
        goodbyeText.setAutoDraw(True)
    
    # if goodbyeText is active this frame...
    if goodbyeText.status == STARTED:
        # update params
        pass
    
    # if goodbyeText is stopping this frame...
    if goodbyeText.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > goodbyeText.tStartRefresh + 3.0-frameTolerance:
            # keep track of stop time/frame for later
            goodbyeText.tStop = t  # not accounting for scr refresh
            goodbyeText.frameNStop = frameN  # exact frame index
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'goodbyeText.stopped')
            # update status
            goodbyeText.status = FINISHED
            goodbyeText.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
        if eyetracker:
            eyetracker.setConnectionState(False)
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in exitComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "exit" ---
for thisComponent in exitComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
if routineForceEnded:
    routineTimer.reset()
else:
    routineTimer.addTime(-3.000000)

# --- End experiment ---
# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
if eyetracker:
    eyetracker.setConnectionState(False)
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
