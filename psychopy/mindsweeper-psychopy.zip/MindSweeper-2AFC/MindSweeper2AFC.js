﻿/************************ 
 * Mindsweeper2Afc Test *
 ************************/

import { core, data, sound, util, visual, hardware } from './lib/psychojs-2023.1.3.js';
const { PsychoJS } = core;
const { TrialHandler, MultiStairHandler } = data;
const { Scheduler } = util;
//some handy aliases as in the psychopy scripts;
const { abs, sin, cos, PI: pi, sqrt } = Math;
const { round } = util;


// store info about the experiment session:
let expName = 'MindSweeper2AFC';  // from the Builder filename that created this script
let expInfo = {
    'participant': `${util.pad(Number.parseFloat(util.randint(0, 999999)).toFixed(0), 6)}`,
    'session': '001',
};

// Start code blocks for 'Before Experiment'
// init psychoJS:
const psychoJS = new PsychoJS({
  debug: true
});

// open window:
psychoJS.openWindow({
  fullscr: true,
  color: new util.Color([0.5, 0.5, 0.5]),
  units: 'pix',
  waitBlanking: true
});
// schedule the experiment:
psychoJS.schedule(psychoJS.gui.DlgFromDict({
  dictionary: expInfo,
  title: expName
}));

const flowScheduler = new Scheduler(psychoJS);
const dialogCancelScheduler = new Scheduler(psychoJS);
psychoJS.scheduleCondition(function() { return (psychoJS.gui.dialogComponent.button === 'OK'); }, flowScheduler, dialogCancelScheduler);

// flowScheduler gets run if the participants presses OK
flowScheduler.add(updateInfo); // add timeStamp
flowScheduler.add(experimentInit);
flowScheduler.add(welcomeRoutineBegin());
flowScheduler.add(welcomeRoutineEachFrame());
flowScheduler.add(welcomeRoutineEnd());
flowScheduler.add(welcomeKeyRoutineBegin());
flowScheduler.add(welcomeKeyRoutineEachFrame());
flowScheduler.add(welcomeKeyRoutineEnd());
flowScheduler.add(instructionsRoutineBegin());
flowScheduler.add(instructionsRoutineEachFrame());
flowScheduler.add(instructionsRoutineEnd());
flowScheduler.add(handsRoutineBegin());
flowScheduler.add(handsRoutineEachFrame());
flowScheduler.add(handsRoutineEnd());
flowScheduler.add(threeRoutineBegin());
flowScheduler.add(threeRoutineEachFrame());
flowScheduler.add(threeRoutineEnd());
flowScheduler.add(twoRoutineBegin());
flowScheduler.add(twoRoutineEachFrame());
flowScheduler.add(twoRoutineEnd());
flowScheduler.add(oneRoutineBegin());
flowScheduler.add(oneRoutineEachFrame());
flowScheduler.add(oneRoutineEnd());
flowScheduler.add(zeroRoutineBegin());
flowScheduler.add(zeroRoutineEachFrame());
flowScheduler.add(zeroRoutineEnd());
const practice_loopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(practice_loopLoopBegin(practice_loopLoopScheduler));
flowScheduler.add(practice_loopLoopScheduler);
flowScheduler.add(practice_loopLoopEnd);
flowScheduler.add(beginRoutineBegin());
flowScheduler.add(beginRoutineEachFrame());
flowScheduler.add(beginRoutineEnd());
const trialsLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(trialsLoopBegin(trialsLoopScheduler));
flowScheduler.add(trialsLoopScheduler);
flowScheduler.add(trialsLoopEnd);
flowScheduler.add(exitRoutineBegin());
flowScheduler.add(exitRoutineEachFrame());
flowScheduler.add(exitRoutineEnd());
flowScheduler.add(quitPsychoJS, '', true);

// quit if user presses Cancel in dialog box:
dialogCancelScheduler.add(quitPsychoJS, '', false);

psychoJS.start({
  expName: expName,
  expInfo: expInfo,
  resources: [
    // resources:
    {'name': 'resources/practice_conditions_df.csv', 'path': 'resources/practice_conditions_df.csv'},
    {'name': './resources/practice_0_black.png', 'path': './resources/practice_0_black.png'},
    {'name': './resources/curve_4_pink.png', 'path': './resources/curve_4_pink.png'},
    {'name': './resources/practice_isecs_0_4.png', 'path': './resources/practice_isecs_0_4.png'},
    {'name': './resources/curve_1_pink.png', 'path': './resources/curve_1_pink.png'},
    {'name': './resources/practice_isecs_0_1.png', 'path': './resources/practice_isecs_0_1.png'},
    {'name': './resources/practice_1_black.png', 'path': './resources/practice_1_black.png'},
    {'name': './resources/practice_isecs_1_1.png', 'path': './resources/practice_isecs_1_1.png'},
    {'name': './resources/curve_0_pink.png', 'path': './resources/curve_0_pink.png'},
    {'name': './resources/practice_isecs_1_0.png', 'path': './resources/practice_isecs_1_0.png'},
    {'name': './resources/practice_2_black.png', 'path': './resources/practice_2_black.png'},
    {'name': './resources/curve_5_pink.png', 'path': './resources/curve_5_pink.png'},
    {'name': './resources/practice_isecs_2_5.png', 'path': './resources/practice_isecs_2_5.png'},
    {'name': './resources/practice_isecs_2_4.png', 'path': './resources/practice_isecs_2_4.png'},
    {'name': './resources/practice_3_black.png', 'path': './resources/practice_3_black.png'},
    {'name': './resources/practice_isecs_3_4.png', 'path': './resources/practice_isecs_3_4.png'},
    {'name': './resources/practice_isecs_3_1.png', 'path': './resources/practice_isecs_3_1.png'},
    {'name': './resources/practice_4_black.png', 'path': './resources/practice_4_black.png'},
    {'name': './resources/curve_3_pink.png', 'path': './resources/curve_3_pink.png'},
    {'name': './resources/practice_isecs_4_3.png', 'path': './resources/practice_isecs_4_3.png'},
    {'name': './resources/practice_isecs_4_5.png', 'path': './resources/practice_isecs_4_5.png'},
    {'name': './resources/practice_5_black.png', 'path': './resources/practice_5_black.png'},
    {'name': './resources/practice_isecs_5_4.png', 'path': './resources/practice_isecs_5_4.png'},
    {'name': './resources/practice_isecs_5_1.png', 'path': './resources/practice_isecs_5_1.png'},
    {'name': 'resources/conditions_df.csv', 'path': 'resources/conditions_df.csv'},
    {'name': './resources/curve_5_black.png', 'path': './resources/curve_5_black.png'},
    {'name': './resources/curve_5_pink.png', 'path': './resources/curve_5_pink.png'},
    {'name': './resources/curve_4_pink.png', 'path': './resources/curve_4_pink.png'},
    {'name': './resources/isecs_5_4.png', 'path': './resources/isecs_5_4.png'},
    {'name': './resources/curve_0_black.png', 'path': './resources/curve_0_black.png'},
    {'name': './resources/curve_3_pink.png', 'path': './resources/curve_3_pink.png'},
    {'name': './resources/isecs_0_3.png', 'path': './resources/isecs_0_3.png'},
    {'name': './resources/curve_2_pink.png', 'path': './resources/curve_2_pink.png'},
    {'name': './resources/isecs_0_2.png', 'path': './resources/isecs_0_2.png'},
    {'name': './resources/curve_7_black.png', 'path': './resources/curve_7_black.png'},
    {'name': './resources/isecs_7_3.png', 'path': './resources/isecs_7_3.png'},
    {'name': './resources/curve_1_pink.png', 'path': './resources/curve_1_pink.png'},
    {'name': './resources/isecs_7_1.png', 'path': './resources/isecs_7_1.png'},
    {'name': './resources/curve_9_black.png', 'path': './resources/curve_9_black.png'},
    {'name': './resources/isecs_9_3.png', 'path': './resources/isecs_9_3.png'},
    {'name': './resources/isecs_9_1.png', 'path': './resources/isecs_9_1.png'},
    {'name': './resources/curve_10_black.png', 'path': './resources/curve_10_black.png'},
    {'name': './resources/isecs_10_5.png', 'path': './resources/isecs_10_5.png'},
    {'name': './resources/isecs_10_1.png', 'path': './resources/isecs_10_1.png'},
    {'name': './resources/curve_6_black.png', 'path': './resources/curve_6_black.png'},
    {'name': './resources/isecs_6_5.png', 'path': './resources/isecs_6_5.png'},
    {'name': './resources/isecs_6_3.png', 'path': './resources/isecs_6_3.png'},
    {'name': './resources/curve_11_black.png', 'path': './resources/curve_11_black.png'},
    {'name': './resources/isecs_11_2.png', 'path': './resources/isecs_11_2.png'},
    {'name': './resources/isecs_11_4.png', 'path': './resources/isecs_11_4.png'},
    {'name': './resources/curve_2_black.png', 'path': './resources/curve_2_black.png'},
    {'name': './resources/curve_0_pink.png', 'path': './resources/curve_0_pink.png'},
    {'name': './resources/isecs_2_0.png', 'path': './resources/isecs_2_0.png'},
    {'name': './resources/isecs_2_4.png', 'path': './resources/isecs_2_4.png'},
    {'name': './resources/isecs_7_2.png', 'path': './resources/isecs_7_2.png'},
    {'name': './resources/isecs_7_5.png', 'path': './resources/isecs_7_5.png'},
    {'name': './resources/curve_1_black.png', 'path': './resources/curve_1_black.png'},
    {'name': './resources/isecs_1_4.png', 'path': './resources/isecs_1_4.png'},
    {'name': './resources/curve_8_black.png', 'path': './resources/curve_8_black.png'},
    {'name': './resources/isecs_8_2.png', 'path': './resources/isecs_8_2.png'},
    {'name': './resources/isecs_8_0.png', 'path': './resources/isecs_8_0.png'},
    {'name': './resources/isecs_9_5.png', 'path': './resources/isecs_9_5.png'},
    {'name': './resources/isecs_10_3.png', 'path': './resources/isecs_10_3.png'},
    {'name': './resources/curve_3_black.png', 'path': './resources/curve_3_black.png'},
    {'name': './resources/isecs_3_2.png', 'path': './resources/isecs_3_2.png'},
    {'name': './resources/isecs_3_5.png', 'path': './resources/isecs_3_5.png'},
    {'name': './resources/isecs_11_5.png', 'path': './resources/isecs_11_5.png'},
    {'name': './resources/isecs_6_1.png', 'path': './resources/isecs_6_1.png'},
    {'name': './resources/isecs_9_2.png', 'path': './resources/isecs_9_2.png'},
    {'name': './resources/isecs_9_0.png', 'path': './resources/isecs_9_0.png'},
    {'name': './resources/isecs_11_3.png', 'path': './resources/isecs_11_3.png'},
    {'name': './resources/isecs_3_1.png', 'path': './resources/isecs_3_1.png'},
    {'name': './resources/isecs_3_0.png', 'path': './resources/isecs_3_0.png'},
    {'name': './resources/isecs_0_5.png', 'path': './resources/isecs_0_5.png'},
    {'name': './resources/isecs_2_5.png', 'path': './resources/isecs_2_5.png'},
    {'name': './resources/isecs_1_0.png', 'path': './resources/isecs_1_0.png'},
    {'name': './resources/isecs_3_4.png', 'path': './resources/isecs_3_4.png'},
    {'name': './resources/isecs_0_4.png', 'path': './resources/isecs_0_4.png'},
    {'name': './resources/curve_4_black.png', 'path': './resources/curve_4_black.png'},
    {'name': './resources/isecs_4_2.png', 'path': './resources/isecs_4_2.png'},
    {'name': './resources/isecs_5_2.png', 'path': './resources/isecs_5_2.png'},
    {'name': './resources/isecs_5_1.png', 'path': './resources/isecs_5_1.png'},
    {'name': './resources/isecs_8_5.png', 'path': './resources/isecs_8_5.png'},
    {'name': './resources/isecs_8_3.png', 'path': './resources/isecs_8_3.png'},
    {'name': './resources/isecs_1_2.png', 'path': './resources/isecs_1_2.png'},
    {'name': './resources/isecs_1_5.png', 'path': './resources/isecs_1_5.png'},
    {'name': './resources/isecs_4_0.png', 'path': './resources/isecs_4_0.png'},
    {'name': './resources/isecs_5_0.png', 'path': './resources/isecs_5_0.png'},
    {'name': './resources/isecs_9_4.png', 'path': './resources/isecs_9_4.png'},
    {'name': './resources/isecs_2_1.png', 'path': './resources/isecs_2_1.png'},
    {'name': './resources/isecs_4_3.png', 'path': './resources/isecs_4_3.png'},
    {'name': './resources/isecs_7_4.png', 'path': './resources/isecs_7_4.png'},
    {'name': './resources/isecs_11_1.png', 'path': './resources/isecs_11_1.png'},
    {'name': './resources/isecs_11_0.png', 'path': './resources/isecs_11_0.png'},
    {'name': './resources/isecs_2_3.png', 'path': './resources/isecs_2_3.png'},
    {'name': './resources/isecs_7_0.png', 'path': './resources/isecs_7_0.png'},
    {'name': './resources/isecs_10_4.png', 'path': './resources/isecs_10_4.png'},
    {'name': './resources/isecs_10_0.png', 'path': './resources/isecs_10_0.png'},
    {'name': './resources/isecs_0_1.png', 'path': './resources/isecs_0_1.png'},
    {'name': './resources/isecs_4_1.png', 'path': './resources/isecs_4_1.png'},
    {'name': './resources/isecs_1_3.png', 'path': './resources/isecs_1_3.png'},
    {'name': './resources/isecs_8_1.png', 'path': './resources/isecs_8_1.png'},
    {'name': './resources/isecs_6_0.png', 'path': './resources/isecs_6_0.png'},
    {'name': './resources/isecs_4_5.png', 'path': './resources/isecs_4_5.png'},
    {'name': './resources/isecs_6_2.png', 'path': './resources/isecs_6_2.png'},
    {'name': './resources/isecs_10_2.png', 'path': './resources/isecs_10_2.png'},
    {'name': './resources/isecs_6_4.png', 'path': './resources/isecs_6_4.png'},
    {'name': './resources/isecs_5_3.png', 'path': './resources/isecs_5_3.png'},
    {'name': './resources/isecs_8_4.png', 'path': './resources/isecs_8_4.png'},
    {'name': 'resources/blank.png', 'path': 'resources/blank.png'},
    {'name': 'default.png', 'path': 'https://pavlovia.org/assets/default/default.png'},
    {'name': 'resources/blank_red.png', 'path': 'resources/blank_red.png'},
  ]
});

psychoJS.experimentLogger.setLevel(core.Logger.ServerLevel.EXP);


var currentLoop;
var frameDur;
async function updateInfo() {
  currentLoop = psychoJS.experiment;  // right now there are no loops
  expInfo['date'] = util.MonotonicClock.getDateStr();  // add a simple timestamp
  expInfo['expName'] = expName;
  expInfo['psychopyVersion'] = '2023.1.3';
  expInfo['OS'] = window.navigator.platform;


  // store frame rate of monitor if we can measure it successfully
  expInfo['frameRate'] = psychoJS.window.getActualFrameRate();
  if (typeof expInfo['frameRate'] !== 'undefined')
    frameDur = 1.0 / Math.round(expInfo['frameRate']);
  else
    frameDur = 1.0 / 60.0; // couldn't get a reliable measure so guess

  // add info from the URL:
  util.addInfoFromUrl(expInfo);
  psychoJS.setRedirectUrls('https://app.prolific.com/submissions/complete?cc=CYA0OIJ2', '');


  
  psychoJS.experiment.dataFileName = (("." + "/") + `data/${expInfo["participant"]}_${expName}_${expInfo["date"]}`);


  return Scheduler.Event.NEXT;
}


var welcomeClock;
var welcomeText;
var welcomeKeyClock;
var welcomeText2;
var key_resp_2;
var instructionsClock;
var intructionsText;
var continue_2;
var handsClock;
var hand_placement;
var procede;
var threeClock;
var three;
var twoClock;
var two;
var oneClock;
var one;
var zeroClock;
var zero;
var warningBluePracticeClock;
var warningBluePract;
var practicePreTargetTxt;
var practiceTargetClock;
var practiceTargetImg;
var practiceTargetText;
var pauseClock;
var blank_img2;
var isiClock;
var blank_img;
var practiceProbeClock;
var practiceResponse;
var practiceProbeImg;
var practiceProbeText;
var practiceFeedbackCorrectClock;
var showIsecsCorrect;
var text_2;
var practiceFeedbackIncorrectClock;
var showIsecsIncorrect;
var incorrectText;
var beginClock;
var text;
var begin_exp;
var warningBlueClock;
var blank_500_red;
var memory_reminder;
var targetClock;
var target_img;
var probeClock;
var probeCurve;
var key_resp;
var comp;
var takeBreakClock;
var rest;
var getReadyClock;
var ready;
var exitClock;
var goodbyeText;
var globalClock;
var routineTimer;
async function experimentInit() {
  // Initialize components for Routine "welcome"
  welcomeClock = new util.Clock();
  welcomeText = new visual.TextStim({
    win: psychoJS.window,
    name: 'welcomeText',
    text: 'Welcome! \n\n[loading experiment]',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 50.0,  wrapWidth: 800.0, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color([(- 1.0), (- 1.0), (- 1.0)]),  opacity: undefined,
    depth: 0.0 
  });
  
  // Initialize components for Routine "welcomeKey"
  welcomeKeyClock = new util.Clock();
  welcomeText2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'welcomeText2',
    text: 'Welcome! \n\n[space to continue]',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 50.0,  wrapWidth: 650.0, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  key_resp_2 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "instructions"
  instructionsClock = new util.Clock();
  intructionsText = new visual.TextStim({
    win: psychoJS.window,
    name: 'intructionsText',
    text: "Instructions (1/2):\n\n(1) A black line or curve will appear on the screen. Memorize it! It will disappear after 3 seconds.\n\n(2) A pink line will appear on the screen. Imagine that the black line/curve that you memorized was displayed on top of the pink line that you see. \n\n(3) How many times would they intersect? If it's more than the number on the screen, press the right arrow key. If it's less, press the left arrow key.\n\nLet’s give it a try!\n\n[space to continue]",
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 35.0,  wrapWidth: 650.0, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  continue_2 = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "hands"
  handsClock = new util.Clock();
  hand_placement = new visual.TextStim({
    win: psychoJS.window,
    name: 'hand_placement',
    text: 'Instructions (2/2):\n\n(1) First, rest your fingers on the keyboard so that you can easily press the left and right arrow keys without having to move your hands. \n\n(2) Got it? Press the spacebar when you’re ready…\n\n[space to continue]',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 35.0,  wrapWidth: 650.0, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  procede = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "three"
  threeClock = new util.Clock();
  three = new visual.TextStim({
    win: psychoJS.window,
    name: 'three',
    text: '3',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 50.0,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  // Initialize components for Routine "two"
  twoClock = new util.Clock();
  two = new visual.TextStim({
    win: psychoJS.window,
    name: 'two',
    text: '2',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 50.0,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  // Initialize components for Routine "one"
  oneClock = new util.Clock();
  one = new visual.TextStim({
    win: psychoJS.window,
    name: 'one',
    text: '1',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 50.0,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  // Initialize components for Routine "zero"
  zeroClock = new util.Clock();
  zero = new visual.TextStim({
    win: psychoJS.window,
    name: 'zero',
    text: '',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 50.0,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: undefined,
    depth: 0.0 
  });
  
  // Initialize components for Routine "warningBluePractice"
  warningBluePracticeClock = new util.Clock();
  warningBluePract = new visual.ImageStim({
    win : psychoJS.window,
    name : 'warningBluePract', units : undefined, 
    image : 'resources/blank.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, pos : [0, 0], size : [750, 750],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  practicePreTargetTxt = new visual.TextStim({
    win: psychoJS.window,
    name: 'practicePreTargetTxt',
    text: 'memorize',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 50], height: 25.0,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color([0.4824, 0.7176, 0.8588]),  opacity: undefined,
    depth: -1.0 
  });
  
  // Initialize components for Routine "practiceTarget"
  practiceTargetClock = new util.Clock();
  practiceTargetImg = new visual.ImageStim({
    win : psychoJS.window,
    name : 'practiceTargetImg', units : undefined, 
    image : 'default.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, pos : [0, 0], size : [750, 750],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  practiceTargetText = new visual.TextStim({
    win: psychoJS.window,
    name: 'practiceTargetText',
    text: '',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 300], height: 30.0,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -1.0 
  });
  
  // Initialize components for Routine "pause"
  pauseClock = new util.Clock();
  blank_img2 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'blank_img2', units : undefined, 
    image : 'resources/blank.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, pos : [0, 0], size : [750, 750],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  // Initialize components for Routine "isi"
  isiClock = new util.Clock();
  blank_img = new visual.ImageStim({
    win : psychoJS.window,
    name : 'blank_img', units : undefined, 
    image : 'resources/blank_red.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, pos : [0, 0], size : [750, 750],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  // Initialize components for Routine "practiceProbe"
  practiceProbeClock = new util.Clock();
  practiceResponse = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  practiceProbeImg = new visual.ImageStim({
    win : psychoJS.window,
    name : 'practiceProbeImg', units : undefined, 
    image : 'default.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, pos : [0, 0], size : [750, 750],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -1.0 
  });
  practiceProbeText = new visual.TextStim({
    win: psychoJS.window,
    name: 'practiceProbeText',
    text: '',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 50], height: 25.0,  wrapWidth: 650.0, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color([0.4824, 0.7176, 0.8588]),  opacity: undefined,
    depth: -3.0 
  });
  
  // Initialize components for Routine "practiceFeedbackCorrect"
  practiceFeedbackCorrectClock = new util.Clock();
  showIsecsCorrect = new visual.ImageStim({
    win : psychoJS.window,
    name : 'showIsecsCorrect', units : undefined, 
    image : 'default.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, pos : [0, 0], size : [750, 750],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  text_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'text_2',
    text: 'Correct! ',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 300], height: 30.0,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -1.0 
  });
  
  // Initialize components for Routine "practiceFeedbackIncorrect"
  practiceFeedbackIncorrectClock = new util.Clock();
  showIsecsIncorrect = new visual.ImageStim({
    win : psychoJS.window,
    name : 'showIsecsIncorrect', units : undefined, 
    image : 'default.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, pos : [0, 0], size : [750, 750],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  incorrectText = new visual.TextStim({
    win: psychoJS.window,
    name: 'incorrectText',
    text: 'Incorrect',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 300], height: 30.0,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -1.0 
  });
  
  // Initialize components for Routine "begin"
  beginClock = new util.Clock();
  text = new visual.TextStim({
    win: psychoJS.window,
    name: 'text',
    text: 'Get ready!\n\nFrom now on, no feedback.\n\n[space to begin experiment]',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 50.0,  wrapWidth: 800.0, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  begin_exp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  // Initialize components for Routine "warningBlue"
  warningBlueClock = new util.Clock();
  blank_500_red = new visual.ImageStim({
    win : psychoJS.window,
    name : 'blank_500_red', units : undefined, 
    image : 'resources/blank.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, pos : [0, 0], size : [750, 750],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  memory_reminder = new visual.TextStim({
    win: psychoJS.window,
    name: 'memory_reminder',
    text: 'memorize',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 50], height: 25.0,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color([0.4824, 0.7176, 0.8588]),  opacity: undefined,
    depth: -1.0 
  });
  
  // Initialize components for Routine "target"
  targetClock = new util.Clock();
  target_img = new visual.ImageStim({
    win : psychoJS.window,
    name : 'target_img', units : undefined, 
    image : 'default.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, pos : [0, 0], size : [750, 750],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  // Initialize components for Routine "probe"
  probeClock = new util.Clock();
  probeCurve = new visual.ImageStim({
    win : psychoJS.window,
    name : 'probeCurve', units : undefined, 
    image : 'default.png', mask : undefined,
    anchor : 'center',
    ori : 0.0, pos : [0, 0], size : [750, 750],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  key_resp = new core.Keyboard({psychoJS: psychoJS, clock: new util.Clock(), waitForStart: true});
  
  comp = new visual.TextStim({
    win: psychoJS.window,
    name: 'comp',
    text: '',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 50], height: 25.0,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color([0.4824, 0.7176, 0.8588]),  opacity: undefined,
    depth: -2.0 
  });
  
  // Initialize components for Routine "takeBreak"
  takeBreakClock = new util.Clock();
  rest = new visual.TextStim({
    win: psychoJS.window,
    name: 'rest',
    text: '',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 50.0,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  // Initialize components for Routine "getReady"
  getReadyClock = new util.Clock();
  ready = new visual.TextStim({
    win: psychoJS.window,
    name: 'ready',
    text: 'Get ready ',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 50.0,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  // Initialize components for Routine "exit"
  exitClock = new util.Clock();
  goodbyeText = new visual.TextStim({
    win: psychoJS.window,
    name: 'goodbyeText',
    text: "You're done! Please wait to be redirected...\n",
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 30.0,  wrapWidth: 650.0, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: 0.0 
  });
  
  // Create some handy timers
  globalClock = new util.Clock();  // to track the time since experiment started
  routineTimer = new util.CountdownTimer();  // to track time remaining of each (non-slip) routine
  
  return Scheduler.Event.NEXT;
}


var t;
var frameN;
var continueRoutine;
var welcomeComponents;
function welcomeRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'welcome' ---
    t = 0;
    welcomeClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(3.000000);
    // update component parameters for each repeat
    // keep track of which components have finished
    welcomeComponents = [];
    welcomeComponents.push(welcomeText);
    
    for (const thisComponent of welcomeComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


var frameRemains;
function welcomeRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'welcome' ---
    // get current time
    t = welcomeClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *welcomeText* updates
    if (t >= 0.0 && welcomeText.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      welcomeText.tStart = t;  // (not accounting for frame time here)
      welcomeText.frameNStart = frameN;  // exact frame index
      
      welcomeText.setAutoDraw(true);
    }

    frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (welcomeText.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      welcomeText.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of welcomeComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function welcomeRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'welcome' ---
    for (const thisComponent of welcomeComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _key_resp_2_allKeys;
var welcomeKeyComponents;
function welcomeKeyRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'welcomeKey' ---
    t = 0;
    welcomeKeyClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    key_resp_2.keys = undefined;
    key_resp_2.rt = undefined;
    _key_resp_2_allKeys = [];
    // keep track of which components have finished
    welcomeKeyComponents = [];
    welcomeKeyComponents.push(welcomeText2);
    welcomeKeyComponents.push(key_resp_2);
    
    for (const thisComponent of welcomeKeyComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function welcomeKeyRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'welcomeKey' ---
    // get current time
    t = welcomeKeyClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *welcomeText2* updates
    if (t >= 0.0 && welcomeText2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      welcomeText2.tStart = t;  // (not accounting for frame time here)
      welcomeText2.frameNStart = frameN;  // exact frame index
      
      welcomeText2.setAutoDraw(true);
    }

    
    // *key_resp_2* updates
    if (t >= 0.0 && key_resp_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_resp_2.tStart = t;  // (not accounting for frame time here)
      key_resp_2.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_resp_2.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_resp_2.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_resp_2.clearEvents(); });
    }

    if (key_resp_2.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_resp_2.getKeys({keyList: ['space'], waitRelease: false});
      _key_resp_2_allKeys = _key_resp_2_allKeys.concat(theseKeys);
      if (_key_resp_2_allKeys.length > 0) {
        key_resp_2.keys = _key_resp_2_allKeys[_key_resp_2_allKeys.length - 1].name;  // just the last key pressed
        key_resp_2.rt = _key_resp_2_allKeys[_key_resp_2_allKeys.length - 1].rt;
        key_resp_2.duration = _key_resp_2_allKeys[_key_resp_2_allKeys.length - 1].duration;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of welcomeKeyComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function welcomeKeyRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'welcomeKey' ---
    for (const thisComponent of welcomeKeyComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(key_resp_2.corr, level);
    }
    psychoJS.experiment.addData('key_resp_2.keys', key_resp_2.keys);
    if (typeof key_resp_2.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('key_resp_2.rt', key_resp_2.rt);
        psychoJS.experiment.addData('key_resp_2.duration', key_resp_2.duration);
        routineTimer.reset();
        }
    
    key_resp_2.stop();
    // the Routine "welcomeKey" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _continue_2_allKeys;
var instructionsComponents;
function instructionsRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'instructions' ---
    t = 0;
    instructionsClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    continue_2.keys = undefined;
    continue_2.rt = undefined;
    _continue_2_allKeys = [];
    // keep track of which components have finished
    instructionsComponents = [];
    instructionsComponents.push(intructionsText);
    instructionsComponents.push(continue_2);
    
    for (const thisComponent of instructionsComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function instructionsRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'instructions' ---
    // get current time
    t = instructionsClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *intructionsText* updates
    if (t >= 0.0 && intructionsText.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      intructionsText.tStart = t;  // (not accounting for frame time here)
      intructionsText.frameNStart = frameN;  // exact frame index
      
      intructionsText.setAutoDraw(true);
    }

    
    // *continue_2* updates
    if (t >= 0.0 && continue_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      continue_2.tStart = t;  // (not accounting for frame time here)
      continue_2.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { continue_2.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { continue_2.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { continue_2.clearEvents(); });
    }

    if (continue_2.status === PsychoJS.Status.STARTED) {
      let theseKeys = continue_2.getKeys({keyList: ['space'], waitRelease: false});
      _continue_2_allKeys = _continue_2_allKeys.concat(theseKeys);
      if (_continue_2_allKeys.length > 0) {
        continue_2.keys = _continue_2_allKeys[_continue_2_allKeys.length - 1].name;  // just the last key pressed
        continue_2.rt = _continue_2_allKeys[_continue_2_allKeys.length - 1].rt;
        continue_2.duration = _continue_2_allKeys[_continue_2_allKeys.length - 1].duration;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of instructionsComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function instructionsRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'instructions' ---
    for (const thisComponent of instructionsComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(continue_2.corr, level);
    }
    psychoJS.experiment.addData('continue_2.keys', continue_2.keys);
    if (typeof continue_2.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('continue_2.rt', continue_2.rt);
        psychoJS.experiment.addData('continue_2.duration', continue_2.duration);
        routineTimer.reset();
        }
    
    continue_2.stop();
    // the Routine "instructions" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _procede_allKeys;
var handsComponents;
function handsRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'hands' ---
    t = 0;
    handsClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    procede.keys = undefined;
    procede.rt = undefined;
    _procede_allKeys = [];
    // keep track of which components have finished
    handsComponents = [];
    handsComponents.push(hand_placement);
    handsComponents.push(procede);
    
    for (const thisComponent of handsComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function handsRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'hands' ---
    // get current time
    t = handsClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *hand_placement* updates
    if (t >= 0.0 && hand_placement.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      hand_placement.tStart = t;  // (not accounting for frame time here)
      hand_placement.frameNStart = frameN;  // exact frame index
      
      hand_placement.setAutoDraw(true);
    }

    
    // *procede* updates
    if (t >= 0.0 && procede.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      procede.tStart = t;  // (not accounting for frame time here)
      procede.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { procede.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { procede.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { procede.clearEvents(); });
    }

    if (procede.status === PsychoJS.Status.STARTED) {
      let theseKeys = procede.getKeys({keyList: ['space'], waitRelease: false});
      _procede_allKeys = _procede_allKeys.concat(theseKeys);
      if (_procede_allKeys.length > 0) {
        procede.keys = _procede_allKeys[_procede_allKeys.length - 1].name;  // just the last key pressed
        procede.rt = _procede_allKeys[_procede_allKeys.length - 1].rt;
        procede.duration = _procede_allKeys[_procede_allKeys.length - 1].duration;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of handsComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function handsRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'hands' ---
    for (const thisComponent of handsComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(procede.corr, level);
    }
    psychoJS.experiment.addData('procede.keys', procede.keys);
    if (typeof procede.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('procede.rt', procede.rt);
        psychoJS.experiment.addData('procede.duration', procede.duration);
        routineTimer.reset();
        }
    
    procede.stop();
    // the Routine "hands" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var threeComponents;
function threeRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'three' ---
    t = 0;
    threeClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(1.200000);
    // update component parameters for each repeat
    // keep track of which components have finished
    threeComponents = [];
    threeComponents.push(three);
    
    for (const thisComponent of threeComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function threeRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'three' ---
    // get current time
    t = threeClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *three* updates
    if (t >= 0.0 && three.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      three.tStart = t;  // (not accounting for frame time here)
      three.frameNStart = frameN;  // exact frame index
      
      three.setAutoDraw(true);
    }

    frameRemains = 0.0 + 1.2 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (three.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      three.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of threeComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function threeRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'three' ---
    for (const thisComponent of threeComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var twoComponents;
function twoRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'two' ---
    t = 0;
    twoClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(1.200000);
    // update component parameters for each repeat
    // keep track of which components have finished
    twoComponents = [];
    twoComponents.push(two);
    
    for (const thisComponent of twoComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function twoRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'two' ---
    // get current time
    t = twoClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *two* updates
    if (t >= 0.0 && two.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      two.tStart = t;  // (not accounting for frame time here)
      two.frameNStart = frameN;  // exact frame index
      
      two.setAutoDraw(true);
    }

    frameRemains = 0.0 + 1.2 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (two.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      two.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of twoComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function twoRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'two' ---
    for (const thisComponent of twoComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var oneComponents;
function oneRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'one' ---
    t = 0;
    oneClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(1.200000);
    // update component parameters for each repeat
    // keep track of which components have finished
    oneComponents = [];
    oneComponents.push(one);
    
    for (const thisComponent of oneComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function oneRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'one' ---
    // get current time
    t = oneClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *one* updates
    if (t >= 0.0 && one.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      one.tStart = t;  // (not accounting for frame time here)
      one.frameNStart = frameN;  // exact frame index
      
      one.setAutoDraw(true);
    }

    frameRemains = 0.0 + 1.2 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (one.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      one.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of oneComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function oneRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'one' ---
    for (const thisComponent of oneComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var zeroComponents;
function zeroRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'zero' ---
    t = 0;
    zeroClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(1.000000);
    // update component parameters for each repeat
    // keep track of which components have finished
    zeroComponents = [];
    zeroComponents.push(zero);
    
    for (const thisComponent of zeroComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function zeroRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'zero' ---
    // get current time
    t = zeroClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *zero* updates
    if (t >= 0.0 && zero.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      zero.tStart = t;  // (not accounting for frame time here)
      zero.frameNStart = frameN;  // exact frame index
      
      zero.setAutoDraw(true);
    }

    frameRemains = 0.0 + 1.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (zero.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      zero.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of zeroComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function zeroRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'zero' ---
    for (const thisComponent of zeroComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var practice_loop;
function practice_loopLoopBegin(practice_loopLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    practice_loop = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'resources/practice_conditions_df.csv',
      seed: undefined, name: 'practice_loop'
    });
    psychoJS.experiment.addLoop(practice_loop); // add the loop to the experiment
    currentLoop = practice_loop;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisPractice_loop of practice_loop) {
      snapshot = practice_loop.getSnapshot();
      practice_loopLoopScheduler.add(importConditions(snapshot));
      const show_target_curve_practiceLoopScheduler = new Scheduler(psychoJS);
      practice_loopLoopScheduler.add(show_target_curve_practiceLoopBegin(show_target_curve_practiceLoopScheduler, snapshot));
      practice_loopLoopScheduler.add(show_target_curve_practiceLoopScheduler);
      practice_loopLoopScheduler.add(show_target_curve_practiceLoopEnd);
      practice_loopLoopScheduler.add(isiRoutineBegin(snapshot));
      practice_loopLoopScheduler.add(isiRoutineEachFrame());
      practice_loopLoopScheduler.add(isiRoutineEnd(snapshot));
      practice_loopLoopScheduler.add(practiceProbeRoutineBegin(snapshot));
      practice_loopLoopScheduler.add(practiceProbeRoutineEachFrame());
      practice_loopLoopScheduler.add(practiceProbeRoutineEnd(snapshot));
      const correctLoopScheduler = new Scheduler(psychoJS);
      practice_loopLoopScheduler.add(correctLoopBegin(correctLoopScheduler, snapshot));
      practice_loopLoopScheduler.add(correctLoopScheduler);
      practice_loopLoopScheduler.add(correctLoopEnd);
      const incorrectLoopScheduler = new Scheduler(psychoJS);
      practice_loopLoopScheduler.add(incorrectLoopBegin(incorrectLoopScheduler, snapshot));
      practice_loopLoopScheduler.add(incorrectLoopScheduler);
      practice_loopLoopScheduler.add(incorrectLoopEnd);
      practice_loopLoopScheduler.add(practice_loopLoopEndIteration(practice_loopLoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


var show_target_curve_practice;
function show_target_curve_practiceLoopBegin(show_target_curve_practiceLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    show_target_curve_practice = new TrialHandler({
      psychoJS: psychoJS,
      nReps: show_target, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: undefined,
      seed: undefined, name: 'show_target_curve_practice'
    });
    psychoJS.experiment.addLoop(show_target_curve_practice); // add the loop to the experiment
    currentLoop = show_target_curve_practice;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisShow_target_curve_practice of show_target_curve_practice) {
      snapshot = show_target_curve_practice.getSnapshot();
      show_target_curve_practiceLoopScheduler.add(importConditions(snapshot));
      show_target_curve_practiceLoopScheduler.add(warningBluePracticeRoutineBegin(snapshot));
      show_target_curve_practiceLoopScheduler.add(warningBluePracticeRoutineEachFrame());
      show_target_curve_practiceLoopScheduler.add(warningBluePracticeRoutineEnd(snapshot));
      show_target_curve_practiceLoopScheduler.add(practiceTargetRoutineBegin(snapshot));
      show_target_curve_practiceLoopScheduler.add(practiceTargetRoutineEachFrame());
      show_target_curve_practiceLoopScheduler.add(practiceTargetRoutineEnd(snapshot));
      show_target_curve_practiceLoopScheduler.add(pauseRoutineBegin(snapshot));
      show_target_curve_practiceLoopScheduler.add(pauseRoutineEachFrame());
      show_target_curve_practiceLoopScheduler.add(pauseRoutineEnd(snapshot));
      show_target_curve_practiceLoopScheduler.add(show_target_curve_practiceLoopEndIteration(show_target_curve_practiceLoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function show_target_curve_practiceLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(show_target_curve_practice);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function show_target_curve_practiceLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var correct;
function correctLoopBegin(correctLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    correct = new TrialHandler({
      psychoJS: psychoJS,
      nReps: isCorrect, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: undefined,
      seed: undefined, name: 'correct'
    });
    psychoJS.experiment.addLoop(correct); // add the loop to the experiment
    currentLoop = correct;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisCorrect of correct) {
      snapshot = correct.getSnapshot();
      correctLoopScheduler.add(importConditions(snapshot));
      correctLoopScheduler.add(practiceFeedbackCorrectRoutineBegin(snapshot));
      correctLoopScheduler.add(practiceFeedbackCorrectRoutineEachFrame());
      correctLoopScheduler.add(practiceFeedbackCorrectRoutineEnd(snapshot));
      correctLoopScheduler.add(correctLoopEndIteration(correctLoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function correctLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(correct);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function correctLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var incorrect;
function incorrectLoopBegin(incorrectLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    incorrect = new TrialHandler({
      psychoJS: psychoJS,
      nReps: isIncorrect, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: undefined,
      seed: undefined, name: 'incorrect'
    });
    psychoJS.experiment.addLoop(incorrect); // add the loop to the experiment
    currentLoop = incorrect;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisIncorrect of incorrect) {
      snapshot = incorrect.getSnapshot();
      incorrectLoopScheduler.add(importConditions(snapshot));
      incorrectLoopScheduler.add(practiceFeedbackIncorrectRoutineBegin(snapshot));
      incorrectLoopScheduler.add(practiceFeedbackIncorrectRoutineEachFrame());
      incorrectLoopScheduler.add(practiceFeedbackIncorrectRoutineEnd(snapshot));
      incorrectLoopScheduler.add(incorrectLoopEndIteration(incorrectLoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function incorrectLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(incorrect);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function incorrectLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      }
    return Scheduler.Event.NEXT;
    }
  };
}


async function practice_loopLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(practice_loop);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function practice_loopLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var trials;
function trialsLoopBegin(trialsLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    trials = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'resources/conditions_df.csv',
      seed: 1, name: 'trials'
    });
    psychoJS.experiment.addLoop(trials); // add the loop to the experiment
    currentLoop = trials;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisTrial of trials) {
      snapshot = trials.getSnapshot();
      trialsLoopScheduler.add(importConditions(snapshot));
      const show_target_curveLoopScheduler = new Scheduler(psychoJS);
      trialsLoopScheduler.add(show_target_curveLoopBegin(show_target_curveLoopScheduler, snapshot));
      trialsLoopScheduler.add(show_target_curveLoopScheduler);
      trialsLoopScheduler.add(show_target_curveLoopEnd);
      trialsLoopScheduler.add(isiRoutineBegin(snapshot));
      trialsLoopScheduler.add(isiRoutineEachFrame());
      trialsLoopScheduler.add(isiRoutineEnd(snapshot));
      trialsLoopScheduler.add(probeRoutineBegin(snapshot));
      trialsLoopScheduler.add(probeRoutineEachFrame());
      trialsLoopScheduler.add(probeRoutineEnd(snapshot));
      const show_break_loopLoopScheduler = new Scheduler(psychoJS);
      trialsLoopScheduler.add(show_break_loopLoopBegin(show_break_loopLoopScheduler, snapshot));
      trialsLoopScheduler.add(show_break_loopLoopScheduler);
      trialsLoopScheduler.add(show_break_loopLoopEnd);
      trialsLoopScheduler.add(trialsLoopEndIteration(trialsLoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


var show_target_curve;
function show_target_curveLoopBegin(show_target_curveLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    show_target_curve = new TrialHandler({
      psychoJS: psychoJS,
      nReps: show_target, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: undefined,
      seed: undefined, name: 'show_target_curve'
    });
    psychoJS.experiment.addLoop(show_target_curve); // add the loop to the experiment
    currentLoop = show_target_curve;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisShow_target_curve of show_target_curve) {
      snapshot = show_target_curve.getSnapshot();
      show_target_curveLoopScheduler.add(importConditions(snapshot));
      show_target_curveLoopScheduler.add(warningBlueRoutineBegin(snapshot));
      show_target_curveLoopScheduler.add(warningBlueRoutineEachFrame());
      show_target_curveLoopScheduler.add(warningBlueRoutineEnd(snapshot));
      show_target_curveLoopScheduler.add(targetRoutineBegin(snapshot));
      show_target_curveLoopScheduler.add(targetRoutineEachFrame());
      show_target_curveLoopScheduler.add(targetRoutineEnd(snapshot));
      show_target_curveLoopScheduler.add(pauseRoutineBegin(snapshot));
      show_target_curveLoopScheduler.add(pauseRoutineEachFrame());
      show_target_curveLoopScheduler.add(pauseRoutineEnd(snapshot));
      show_target_curveLoopScheduler.add(show_target_curveLoopEndIteration(show_target_curveLoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function show_target_curveLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(show_target_curve);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function show_target_curveLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var show_break_loop;
function show_break_loopLoopBegin(show_break_loopLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    show_break_loop = new TrialHandler({
      psychoJS: psychoJS,
      nReps: show_break, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: undefined,
      seed: undefined, name: 'show_break_loop'
    });
    psychoJS.experiment.addLoop(show_break_loop); // add the loop to the experiment
    currentLoop = show_break_loop;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisShow_break_loop of show_break_loop) {
      snapshot = show_break_loop.getSnapshot();
      show_break_loopLoopScheduler.add(importConditions(snapshot));
      show_break_loopLoopScheduler.add(takeBreakRoutineBegin(snapshot));
      show_break_loopLoopScheduler.add(takeBreakRoutineEachFrame());
      show_break_loopLoopScheduler.add(takeBreakRoutineEnd(snapshot));
      show_break_loopLoopScheduler.add(getReadyRoutineBegin(snapshot));
      show_break_loopLoopScheduler.add(getReadyRoutineEachFrame());
      show_break_loopLoopScheduler.add(getReadyRoutineEnd(snapshot));
      show_break_loopLoopScheduler.add(show_break_loopLoopEndIteration(show_break_loopLoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function show_break_loopLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(show_break_loop);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function show_break_loopLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      }
    return Scheduler.Event.NEXT;
    }
  };
}


async function trialsLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(trials);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function trialsLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var warningBluePracticeComponents;
function warningBluePracticeRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'warningBluePractice' ---
    t = 0;
    warningBluePracticeClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(2.000000);
    // update component parameters for each repeat
    // keep track of which components have finished
    warningBluePracticeComponents = [];
    warningBluePracticeComponents.push(warningBluePract);
    warningBluePracticeComponents.push(practicePreTargetTxt);
    
    for (const thisComponent of warningBluePracticeComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function warningBluePracticeRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'warningBluePractice' ---
    // get current time
    t = warningBluePracticeClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *warningBluePract* updates
    if (t >= 0.0 && warningBluePract.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      warningBluePract.tStart = t;  // (not accounting for frame time here)
      warningBluePract.frameNStart = frameN;  // exact frame index
      
      warningBluePract.setAutoDraw(true);
    }

    frameRemains = 0.0 + 2 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (warningBluePract.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      warningBluePract.setAutoDraw(false);
    }
    
    // *practicePreTargetTxt* updates
    if (t >= 0.5 && practicePreTargetTxt.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      practicePreTargetTxt.tStart = t;  // (not accounting for frame time here)
      practicePreTargetTxt.frameNStart = frameN;  // exact frame index
      
      practicePreTargetTxt.setAutoDraw(true);
    }

    frameRemains = 0.5 + 1 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (practicePreTargetTxt.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      practicePreTargetTxt.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of warningBluePracticeComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function warningBluePracticeRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'warningBluePractice' ---
    for (const thisComponent of warningBluePracticeComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var practiceTargetComponents;
function practiceTargetRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'practiceTarget' ---
    t = 0;
    practiceTargetClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(3.000000);
    // update component parameters for each repeat
    practiceTargetImg.setImage(target_file);
    practiceTargetText.setText('\n');
    // keep track of which components have finished
    practiceTargetComponents = [];
    practiceTargetComponents.push(practiceTargetImg);
    practiceTargetComponents.push(practiceTargetText);
    
    for (const thisComponent of practiceTargetComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function practiceTargetRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'practiceTarget' ---
    // get current time
    t = practiceTargetClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *practiceTargetImg* updates
    if (t >= 0.0 && practiceTargetImg.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      practiceTargetImg.tStart = t;  // (not accounting for frame time here)
      practiceTargetImg.frameNStart = frameN;  // exact frame index
      
      practiceTargetImg.setAutoDraw(true);
    }

    frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (practiceTargetImg.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      practiceTargetImg.setAutoDraw(false);
    }
    
    // *practiceTargetText* updates
    if (t >= 0.0 && practiceTargetText.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      practiceTargetText.tStart = t;  // (not accounting for frame time here)
      practiceTargetText.frameNStart = frameN;  // exact frame index
      
      practiceTargetText.setAutoDraw(true);
    }

    frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (practiceTargetText.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      practiceTargetText.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of practiceTargetComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function practiceTargetRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'practiceTarget' ---
    for (const thisComponent of practiceTargetComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var pauseComponents;
function pauseRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'pause' ---
    t = 0;
    pauseClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(0.200000);
    // update component parameters for each repeat
    // keep track of which components have finished
    pauseComponents = [];
    pauseComponents.push(blank_img2);
    
    for (const thisComponent of pauseComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function pauseRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'pause' ---
    // get current time
    t = pauseClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *blank_img2* updates
    if (t >= 0.0 && blank_img2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      blank_img2.tStart = t;  // (not accounting for frame time here)
      blank_img2.frameNStart = frameN;  // exact frame index
      
      blank_img2.setAutoDraw(true);
    }

    frameRemains = 0.0 + 0.2 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (blank_img2.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      blank_img2.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of pauseComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function pauseRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'pause' ---
    for (const thisComponent of pauseComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var isiComponents;
function isiRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'isi' ---
    t = 0;
    isiClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(0.500000);
    // update component parameters for each repeat
    // keep track of which components have finished
    isiComponents = [];
    isiComponents.push(blank_img);
    
    for (const thisComponent of isiComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function isiRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'isi' ---
    // get current time
    t = isiClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *blank_img* updates
    if (t >= 0.0 && blank_img.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      blank_img.tStart = t;  // (not accounting for frame time here)
      blank_img.frameNStart = frameN;  // exact frame index
      
      blank_img.setAutoDraw(true);
    }

    frameRemains = 0.0 + 0.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (blank_img.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      blank_img.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of isiComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function isiRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'isi' ---
    for (const thisComponent of isiComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _practiceResponse_allKeys;
var practiceProbeComponents;
function practiceProbeRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'practiceProbe' ---
    t = 0;
    practiceProbeClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    practiceResponse.keys = undefined;
    practiceResponse.rt = undefined;
    _practiceResponse_allKeys = [];
    practiceProbeImg.setImage(probe_file);
    practiceProbeText.setText(comparator);
    // keep track of which components have finished
    practiceProbeComponents = [];
    practiceProbeComponents.push(practiceResponse);
    practiceProbeComponents.push(practiceProbeImg);
    practiceProbeComponents.push(practiceProbeText);
    
    for (const thisComponent of practiceProbeComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function practiceProbeRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'practiceProbe' ---
    // get current time
    t = practiceProbeClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *practiceResponse* updates
    if (t >= 0.0 && practiceResponse.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      practiceResponse.tStart = t;  // (not accounting for frame time here)
      practiceResponse.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { practiceResponse.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { practiceResponse.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { practiceResponse.clearEvents(); });
    }

    if (practiceResponse.status === PsychoJS.Status.STARTED) {
      let theseKeys = practiceResponse.getKeys({keyList: ['right', 'left'], waitRelease: false});
      _practiceResponse_allKeys = _practiceResponse_allKeys.concat(theseKeys);
      if (_practiceResponse_allKeys.length > 0) {
        practiceResponse.keys = _practiceResponse_allKeys[_practiceResponse_allKeys.length - 1].name;  // just the last key pressed
        practiceResponse.rt = _practiceResponse_allKeys[_practiceResponse_allKeys.length - 1].rt;
        practiceResponse.duration = _practiceResponse_allKeys[_practiceResponse_allKeys.length - 1].duration;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    
    // *practiceProbeImg* updates
    if (t >= 0.0 && practiceProbeImg.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      practiceProbeImg.tStart = t;  // (not accounting for frame time here)
      practiceProbeImg.frameNStart = frameN;  // exact frame index
      
      practiceProbeImg.setAutoDraw(true);
    }

    
    // *practiceProbeText* updates
    if (t >= 0.0 && practiceProbeText.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      practiceProbeText.tStart = t;  // (not accounting for frame time here)
      practiceProbeText.frameNStart = frameN;  // exact frame index
      
      practiceProbeText.setAutoDraw(true);
    }

    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of practiceProbeComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


var isCorrect;
var isIncorrect;
function practiceProbeRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'practiceProbe' ---
    for (const thisComponent of practiceProbeComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(practiceResponse.corr, level);
    }
    psychoJS.experiment.addData('practiceResponse.keys', practiceResponse.keys);
    if (typeof practiceResponse.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('practiceResponse.rt', practiceResponse.rt);
        psychoJS.experiment.addData('practiceResponse.duration', practiceResponse.duration);
        routineTimer.reset();
        }
    
    practiceResponse.stop();
    // Run 'End Routine' code from code
    if ((practiceResponse.keys === correct_resp)) {
        isCorrect = 1;
        isIncorrect = 0;
    } else {
        isCorrect = 0;
        isIncorrect = 1;
    }
    
    // the Routine "practiceProbe" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var practiceFeedbackCorrectComponents;
function practiceFeedbackCorrectRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'practiceFeedbackCorrect' ---
    t = 0;
    practiceFeedbackCorrectClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(3.000000);
    // update component parameters for each repeat
    showIsecsCorrect.setImage(isecs_image);
    // keep track of which components have finished
    practiceFeedbackCorrectComponents = [];
    practiceFeedbackCorrectComponents.push(showIsecsCorrect);
    practiceFeedbackCorrectComponents.push(text_2);
    
    for (const thisComponent of practiceFeedbackCorrectComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function practiceFeedbackCorrectRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'practiceFeedbackCorrect' ---
    // get current time
    t = practiceFeedbackCorrectClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *showIsecsCorrect* updates
    if (t >= 0.0 && showIsecsCorrect.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      showIsecsCorrect.tStart = t;  // (not accounting for frame time here)
      showIsecsCorrect.frameNStart = frameN;  // exact frame index
      
      showIsecsCorrect.setAutoDraw(true);
    }

    frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (showIsecsCorrect.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      showIsecsCorrect.setAutoDraw(false);
    }
    
    // *text_2* updates
    if (t >= 0.0 && text_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text_2.tStart = t;  // (not accounting for frame time here)
      text_2.frameNStart = frameN;  // exact frame index
      
      text_2.setAutoDraw(true);
    }

    frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (text_2.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      text_2.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of practiceFeedbackCorrectComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function practiceFeedbackCorrectRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'practiceFeedbackCorrect' ---
    for (const thisComponent of practiceFeedbackCorrectComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var practiceFeedbackIncorrectComponents;
function practiceFeedbackIncorrectRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'practiceFeedbackIncorrect' ---
    t = 0;
    practiceFeedbackIncorrectClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(3.000000);
    // update component parameters for each repeat
    showIsecsIncorrect.setImage(isecs_image);
    // keep track of which components have finished
    practiceFeedbackIncorrectComponents = [];
    practiceFeedbackIncorrectComponents.push(showIsecsIncorrect);
    practiceFeedbackIncorrectComponents.push(incorrectText);
    
    for (const thisComponent of practiceFeedbackIncorrectComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function practiceFeedbackIncorrectRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'practiceFeedbackIncorrect' ---
    // get current time
    t = practiceFeedbackIncorrectClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *showIsecsIncorrect* updates
    if (t >= 0.0 && showIsecsIncorrect.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      showIsecsIncorrect.tStart = t;  // (not accounting for frame time here)
      showIsecsIncorrect.frameNStart = frameN;  // exact frame index
      
      showIsecsIncorrect.setAutoDraw(true);
    }

    frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (showIsecsIncorrect.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      showIsecsIncorrect.setAutoDraw(false);
    }
    
    // *incorrectText* updates
    if (t >= 0.0 && incorrectText.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      incorrectText.tStart = t;  // (not accounting for frame time here)
      incorrectText.frameNStart = frameN;  // exact frame index
      
      incorrectText.setAutoDraw(true);
    }

    frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (incorrectText.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      incorrectText.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of practiceFeedbackIncorrectComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function practiceFeedbackIncorrectRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'practiceFeedbackIncorrect' ---
    for (const thisComponent of practiceFeedbackIncorrectComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _begin_exp_allKeys;
var beginComponents;
function beginRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'begin' ---
    t = 0;
    beginClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    begin_exp.keys = undefined;
    begin_exp.rt = undefined;
    _begin_exp_allKeys = [];
    // keep track of which components have finished
    beginComponents = [];
    beginComponents.push(text);
    beginComponents.push(begin_exp);
    
    for (const thisComponent of beginComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function beginRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'begin' ---
    // get current time
    t = beginClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *text* updates
    if (t >= 0.0 && text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text.tStart = t;  // (not accounting for frame time here)
      text.frameNStart = frameN;  // exact frame index
      
      text.setAutoDraw(true);
    }

    
    // *begin_exp* updates
    if (t >= 0.0 && begin_exp.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      begin_exp.tStart = t;  // (not accounting for frame time here)
      begin_exp.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { begin_exp.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { begin_exp.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { begin_exp.clearEvents(); });
    }

    if (begin_exp.status === PsychoJS.Status.STARTED) {
      let theseKeys = begin_exp.getKeys({keyList: ['space'], waitRelease: false});
      _begin_exp_allKeys = _begin_exp_allKeys.concat(theseKeys);
      if (_begin_exp_allKeys.length > 0) {
        begin_exp.keys = _begin_exp_allKeys[_begin_exp_allKeys.length - 1].name;  // just the last key pressed
        begin_exp.rt = _begin_exp_allKeys[_begin_exp_allKeys.length - 1].rt;
        begin_exp.duration = _begin_exp_allKeys[_begin_exp_allKeys.length - 1].duration;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of beginComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function beginRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'begin' ---
    for (const thisComponent of beginComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(begin_exp.corr, level);
    }
    psychoJS.experiment.addData('begin_exp.keys', begin_exp.keys);
    if (typeof begin_exp.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('begin_exp.rt', begin_exp.rt);
        psychoJS.experiment.addData('begin_exp.duration', begin_exp.duration);
        routineTimer.reset();
        }
    
    begin_exp.stop();
    // the Routine "begin" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var warningBlueComponents;
function warningBlueRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'warningBlue' ---
    t = 0;
    warningBlueClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(2.000000);
    // update component parameters for each repeat
    // keep track of which components have finished
    warningBlueComponents = [];
    warningBlueComponents.push(blank_500_red);
    warningBlueComponents.push(memory_reminder);
    
    for (const thisComponent of warningBlueComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function warningBlueRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'warningBlue' ---
    // get current time
    t = warningBlueClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *blank_500_red* updates
    if (t >= 0 && blank_500_red.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      blank_500_red.tStart = t;  // (not accounting for frame time here)
      blank_500_red.frameNStart = frameN;  // exact frame index
      
      blank_500_red.setAutoDraw(true);
    }

    frameRemains = 0 + 2 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (blank_500_red.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      blank_500_red.setAutoDraw(false);
    }
    
    // *memory_reminder* updates
    if (t >= 0.5 && memory_reminder.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      memory_reminder.tStart = t;  // (not accounting for frame time here)
      memory_reminder.frameNStart = frameN;  // exact frame index
      
      memory_reminder.setAutoDraw(true);
    }

    frameRemains = 0.5 + 1.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (memory_reminder.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      memory_reminder.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of warningBlueComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function warningBlueRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'warningBlue' ---
    for (const thisComponent of warningBlueComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var targetComponents;
function targetRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'target' ---
    t = 0;
    targetClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(2.800000);
    // update component parameters for each repeat
    target_img.setImage(target_file);
    // keep track of which components have finished
    targetComponents = [];
    targetComponents.push(target_img);
    
    for (const thisComponent of targetComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function targetRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'target' ---
    // get current time
    t = targetClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *target_img* updates
    if (t >= 0.0 && target_img.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      target_img.tStart = t;  // (not accounting for frame time here)
      target_img.frameNStart = frameN;  // exact frame index
      
      target_img.setAutoDraw(true);
    }

    frameRemains = 0.0 + 2.8 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (target_img.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      target_img.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of targetComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function targetRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'target' ---
    for (const thisComponent of targetComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var _key_resp_allKeys;
var probeComponents;
function probeRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'probe' ---
    t = 0;
    probeClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(10.000000);
    // update component parameters for each repeat
    probeCurve.setImage(probe_file);
    key_resp.keys = undefined;
    key_resp.rt = undefined;
    _key_resp_allKeys = [];
    comp.setText(comparator);
    // keep track of which components have finished
    probeComponents = [];
    probeComponents.push(probeCurve);
    probeComponents.push(key_resp);
    probeComponents.push(comp);
    
    for (const thisComponent of probeComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function probeRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'probe' ---
    // get current time
    t = probeClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *probeCurve* updates
    if (t >= 0.0 && probeCurve.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      probeCurve.tStart = t;  // (not accounting for frame time here)
      probeCurve.frameNStart = frameN;  // exact frame index
      
      probeCurve.setAutoDraw(true);
    }

    frameRemains = 0.0 + 10 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (probeCurve.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      probeCurve.setAutoDraw(false);
    }
    
    // *key_resp* updates
    if (t >= 0.0 && key_resp.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      key_resp.tStart = t;  // (not accounting for frame time here)
      key_resp.frameNStart = frameN;  // exact frame index
      
      // keyboard checking is just starting
      psychoJS.window.callOnFlip(function() { key_resp.clock.reset(); });  // t=0 on next screen flip
      psychoJS.window.callOnFlip(function() { key_resp.start(); }); // start on screen flip
      psychoJS.window.callOnFlip(function() { key_resp.clearEvents(); });
    }

    frameRemains = 0.0 + 10 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (key_resp.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      key_resp.status = PsychoJS.Status.FINISHED;
  }

    if (key_resp.status === PsychoJS.Status.STARTED) {
      let theseKeys = key_resp.getKeys({keyList: ['left', 'right'], waitRelease: false});
      _key_resp_allKeys = _key_resp_allKeys.concat(theseKeys);
      if (_key_resp_allKeys.length > 0) {
        key_resp.keys = _key_resp_allKeys[_key_resp_allKeys.length - 1].name;  // just the last key pressed
        key_resp.rt = _key_resp_allKeys[_key_resp_allKeys.length - 1].rt;
        key_resp.duration = _key_resp_allKeys[_key_resp_allKeys.length - 1].duration;
        // a response ends the routine
        continueRoutine = false;
      }
    }
    
    
    // *comp* updates
    if (t >= 0.0 && comp.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      comp.tStart = t;  // (not accounting for frame time here)
      comp.frameNStart = frameN;  // exact frame index
      
      comp.setAutoDraw(true);
    }

    frameRemains = 0.0 + 10 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (comp.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      comp.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of probeComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function probeRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'probe' ---
    for (const thisComponent of probeComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // update the trial handler
    if (currentLoop instanceof MultiStairHandler) {
      currentLoop.addResponse(key_resp.corr, level);
    }
    psychoJS.experiment.addData('key_resp.keys', key_resp.keys);
    if (typeof key_resp.keys !== 'undefined') {  // we had a response
        psychoJS.experiment.addData('key_resp.rt', key_resp.rt);
        psychoJS.experiment.addData('key_resp.duration', key_resp.duration);
        routineTimer.reset();
        }
    
    key_resp.stop();
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var takeBreakComponents;
function takeBreakRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'takeBreak' ---
    t = 0;
    takeBreakClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(60.000000);
    // update component parameters for each repeat
    rest.setText((("Block complete\n\n" + "Take a break\n\n") + "(60 seconds)"));
    // keep track of which components have finished
    takeBreakComponents = [];
    takeBreakComponents.push(rest);
    
    for (const thisComponent of takeBreakComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function takeBreakRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'takeBreak' ---
    // get current time
    t = takeBreakClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *rest* updates
    if (t >= 0.0 && rest.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      rest.tStart = t;  // (not accounting for frame time here)
      rest.frameNStart = frameN;  // exact frame index
      
      rest.setAutoDraw(true);
    }

    frameRemains = 0.0 + 60 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (rest.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      rest.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of takeBreakComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function takeBreakRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'takeBreak' ---
    for (const thisComponent of takeBreakComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var getReadyComponents;
function getReadyRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'getReady' ---
    t = 0;
    getReadyClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(10.000000);
    // update component parameters for each repeat
    // keep track of which components have finished
    getReadyComponents = [];
    getReadyComponents.push(ready);
    
    for (const thisComponent of getReadyComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function getReadyRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'getReady' ---
    // get current time
    t = getReadyClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *ready* updates
    if (t >= 0.0 && ready.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ready.tStart = t;  // (not accounting for frame time here)
      ready.frameNStart = frameN;  // exact frame index
      
      ready.setAutoDraw(true);
    }

    frameRemains = 0.0 + 10.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (ready.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      ready.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of getReadyComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function getReadyRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'getReady' ---
    for (const thisComponent of getReadyComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var exitComponents;
function exitRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'exit' ---
    t = 0;
    exitClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(3.000000);
    // update component parameters for each repeat
    // keep track of which components have finished
    exitComponents = [];
    exitComponents.push(goodbyeText);
    
    for (const thisComponent of exitComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function exitRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'exit' ---
    // get current time
    t = exitClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *goodbyeText* updates
    if (t >= 0.0 && goodbyeText.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      goodbyeText.tStart = t;  // (not accounting for frame time here)
      goodbyeText.frameNStart = frameN;  // exact frame index
      
      goodbyeText.setAutoDraw(true);
    }

    frameRemains = 0.0 + 3.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (goodbyeText.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      goodbyeText.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of exitComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function exitRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'exit' ---
    for (const thisComponent of exitComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


function importConditions(currentLoop) {
  return async function () {
    psychoJS.importAttributes(currentLoop.getCurrentTrial());
    return Scheduler.Event.NEXT;
    };
}


async function quitPsychoJS(message, isCompleted) {
  // Check for and save orphaned data
  if (psychoJS.experiment.isEntryEmpty()) {
    psychoJS.experiment.nextEntry();
  }
  
  
  psychoJS.window.close();
  psychoJS.quit({message: message, isCompleted: isCompleted});
  
  return Scheduler.Event.QUIT;
}
